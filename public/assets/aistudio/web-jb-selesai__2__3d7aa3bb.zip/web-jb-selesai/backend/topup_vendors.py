"""Topup supplier (vendor) integrations.

A *supplier* is an upstream service that delivers the actual top up — Digiflazz,
VIP Reseller, or any custom HTTP vendor. Credentials live in the database
(collection ``topup_providers``) so admins can add and switch suppliers from the
panel without redeploying.

Every adapter returns the same normalised shapes:

    AccountCheck(checked, valid, nickname, message, raw)
    Fulfilment(dispatched, status, message, raw, reference, sn)

Failures never block a sale: ``fulfil()`` falls back to the manual admin queue.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Mapping

import httpx

from db import topup_providers, transactions, now_iso
from topup_catalog import find_denomination

logger = logging.getLogger("topup.vendor")


class VendorError(Exception):
    """Raised for configuration problems that should be surfaced to the admin."""


@dataclass
class AccountCheck:
    checked: bool
    valid: bool
    nickname: str | None = None
    message: str = ""
    raw: dict = field(default_factory=dict)


@dataclass
class Fulfilment:
    dispatched: bool
    status: str = "queued_manual"
    message: str = ""
    reference: str = ""
    sn: str = ""
    raw: dict = field(default_factory=dict)


@dataclass
class PrepaidProduct:
    """A supplier SKU, used when importing the catalog."""

    sku: str
    name: str
    category: str = ""
    brand: str = ""
    type: str = ""
    seller_name: str = ""
    price: int = 0
    buyer_product_status: bool = True
    seller_product_status: bool = True
    unlimited_stock: bool = True
    stock: int = 0
    multi: bool = False


# --------------------------------------------------------------------- adapter
class TopupVendor:
    """Base class: never raises from check/fulfil, always degrades gracefully."""

    kind = "manual"

    def __init__(self, config: Mapping[str, Any] | None = None) -> None:
        self.config = dict(config or {})

    # --- metadata shown in the admin panel ---
    @classmethod
    def describe(cls) -> dict:
        raise NotImplementedError

    # --- behaviour ---
    def available(self) -> bool:
        return False

    def auto_dispatch(self) -> bool:
        return bool(self.config.get("auto_dispatch"))

    async def check_account(self, game: Mapping[str, Any], destination: Mapping[str, Any]) -> AccountCheck:
        return AccountCheck(checked=False, valid=True, message="Pengecekan akun tidak didukung supplier ini")

    async def fulfil(self, order: Mapping[str, Any], game: Mapping[str, Any],
                     destination: Mapping[str, Any], product: Mapping[str, Any] | None = None) -> Fulfilment:
        return Fulfilment(dispatched=False, message="Pesanan masuk antrean admin")

    async def balance(self) -> dict:
        return {"supported": False, "message": "Cek saldo tidak didukung supplier ini"}

    async def list_products(self) -> list[PrepaidProduct]:
        return []

    async def test(self) -> dict:
        """Connectivity test used by the admin panel."""
        return {"ok": False, "message": "Supplier belum dikonfigurasi"}

    # --- helpers for subclasses ---
    def _cred(self, key: str, default: str = "") -> str:
        return str(self.config.get(key) or default).strip()

    def sku_for(self, game: Mapping[str, Any], denomination: Mapping[str, Any]) -> str:
        """Supplier SKU: per-denomination override, else per-game prefix."""
        explicit = (denomination.get("vendor_sku") or "").strip()
        if explicit:
            return explicit
        prefix = (game.get("vendor_prefix") or "").strip()
        code = str(denomination.get("code") or "")
        return f"{prefix}{code}" if prefix else code


class ManualVendor(TopupVendor):
    kind = "manual"

    @classmethod
    def describe(cls) -> dict:
        return {
            "kind": "manual",
            "label": "Manual (Admin)",
            "description": "Pesanan masuk ke panel admin dan dikirim manual oleh CS.",
            "fields": [],
            "supports": {"check": False, "balance": False, "import": False},
        }

    def available(self) -> bool:
        return True


class DigiflazzVendor(TopupVendor):
    """Digiflazz prepaid API.

    Credentials: ``username`` + ``api_key`` (production) or ``dev_key`` for the
    development endpoint. Requests are signed with
    ``md5(username + api_key + ref_id)`` as required by Digiflazz.
    """

    kind = "digiflazz"
    BASE = "https://api.digiflazz.com/v1"

    @classmethod
    def describe(cls) -> dict:
        return {
            "kind": "digiflazz",
            "label": "Digiflazz",
            "description": "Supplier PPOB/top up Indonesia. Cek akun, saldo, dan impor produk.",
            "fields": [
                {"key": "username", "label": "Username Digiflazz", "required": True, "secret": False},
                {"key": "api_key", "label": "API Key (Production)", "required": True, "secret": True},
                {"key": "dev_key", "label": "Development Key (opsional)", "required": False, "secret": True},
                {"key": "use_dev", "label": "Pakai endpoint development", "required": False, "secret": False,
                 "type": "boolean"},
                {"key": "brand_override", "label": "Brand Digiflazz (opsional)", "required": False, "secret": False},
            ],
            "supports": {"check": True, "balance": True, "import": True},
        }

    # ---------------------------------------------------------------- request
    def _use_dev(self) -> bool:
        value = self.config.get("use_dev")
        return value in (True, 1, "1", "true", "True", "yes")

    def _signing_key(self) -> str:
        return self._cred("dev_key") if (self._use_dev() and self._cred("dev_key")) else self._cred("api_key")

    def available(self) -> bool:
        return bool(self._cred("username") and self._signing_key())

    def _sign(self, ref_id: str) -> str:
        raw = f"{self._cred('username')}{self._signing_key()}{ref_id}"
        return hashlib.md5(raw.encode()).hexdigest()

    async def _post(self, path: str, payload: dict) -> dict:
        if not self.available():
            raise VendorError("Username/API key Digiflazz belum diisi")
        body = {**payload, "username": self._cred("username"), "sign": self._sign(str(payload.get("ref_id", "")))}
        if self._use_dev():
            body["testing"] = True
        try:
            async with httpx.AsyncClient(timeout=20.0) as http:
                res = await http.post(
                    f"{self.BASE}{path}",
                    json=body,
                    headers={"content-type": "application/json", "Accept": "application/json"},
                )
            res.raise_for_status()
            return res.json() if res.content else {}
        except httpx.HTTPStatusError as exc:
            logger.error("Digiflazz %s error %s: %s", path, exc.response.status_code, exc.response.text[:300])
            raise VendorError(f"Digiflazz menolak permintaan (HTTP {exc.response.status_code})") from exc
        except (httpx.HTTPError, ValueError) as exc:
            logger.error("Digiflazz %s connection error: %s", path, exc)
            raise VendorError("Tidak dapat terhubung ke Digiflazz") from exc

    @staticmethod
    def _data(resp: Mapping[str, Any]) -> dict:
        data = resp.get("data") if isinstance(resp, Mapping) else None
        if isinstance(data, dict):
            return data
        if isinstance(data, list) and data:
            return data[0] if isinstance(data[0], dict) else {}
        return dict(resp or {})

    # ------------------------------------------------------------ operations
    async def check_account(self, game: Mapping[str, Any], destination: Mapping[str, Any]) -> AccountCheck:
        if not self.available():
            return AccountCheck(checked=False, valid=True, message="Supplier Digiflazz belum dikonfigurasi")
        # Digiflazz takes the game/customer number; games using a separate server
        # pass it joined by the admin-configured separator (default "-").
        target = str(destination.get("user_id") or "").strip()
        server = str(destination.get("server_id") or "").strip()
        sep = str(self.config.get("server_separator") or "-")
        customer_no = f"{target}{sep}{server}" if server else target
        code = str(game.get("vendor_prefix") or game.get("slug") or "")
        try:
            resp = await self._post("/cek-saldo", {"cmd": "prepaid"})  # connectivity guard
            data = await self._post(
                "/transaction",
                {
                    "commands": "inq-pasca",
                    "customer_no": customer_no,
                    "ref_id": f"CHK{int(time.time())}",
                    "buyer_sku_code": code,
                },
            )
        except VendorError as exc:
            if "belum diisi" in str(exc):
                return AccountCheck(checked=False, valid=True, message=str(exc))
            logger.info("Digiflazz account check unavailable for %s: %s", code, exc)
            return AccountCheck(checked=False, valid=True, message="Cek akun otomatis gagal, lanjutkan & admin akan memverifikasi")
        body = self._data(data)
        valid = str(body.get("rc", "")).strip() in ("00", "0") or bool(body.get("customer_name"))
        return AccountCheck(
            checked=True,
            valid=valid,
            nickname=body.get("customer_name") or body.get("customer_no"),
            message=body.get("message") or ("Akun ditemukan" if valid else "Akun tidak ditemukan"),
            raw=data if isinstance(data, dict) else {},
        )

    async def fulfil(self, order: Mapping[str, Any], game: Mapping[str, Any],
                     destination: Mapping[str, Any], product: Mapping[str, Any] | None = None) -> Fulfilment:
        if not self.available():
            return Fulfilment(dispatched=False, message="Supplier Digiflazz belum dikonfigurasi")

        denom = None
        if product is not None:
            denom = product.get("denomination") or {}
        if not denom:
            denom = find_denomination(game, order.get("denomination_code")) or {}
        sku = self.sku_for(game, denom)
        if not sku:
            return Fulfilment(dispatched=False, message="SKU Digiflazz belum diatur untuk nominal ini")

        target = str(destination.get("user_id") or "").strip()
        server = str(destination.get("server_id") or "").strip()
        sep = str(self.config.get("server_separator") or "-")
        customer_no = f"{target}{sep}{server}" if server else target
        ref_id = str(order.get("session_id") or "")

        try:
            data = await self._post("/transaction", {
                "buyer_sku_code": sku,
                "customer_no": customer_no,
                "ref_id": ref_id,
            })
        except VendorError as exc:
            logger.error("Digiflazz dispatch failed for %s: %s", ref_id, exc)
            return Fulfilment(dispatched=False, message=str(exc))

        body = self._data(data)
        status = str(body.get("status") or "").strip().lower()
        rc = str(body.get("rc") or "").strip()
        success = status in ("sukses", "success") or rc in ("00", "0")
        pending = status in ("pending", "pnd") or rc in ("03", "04", "05")
        message = body.get("message") or ("Pesanan dikirim ke Digiflazz" if success or pending else "Digiflazz gagal memproses")
        return Fulfilment(
            dispatched=success or pending,
            status="delivered" if success else "processing" if pending else "failed",
            message=message,
            reference=str(body.get("ref_id") or ref_id),
            sn=str(body.get("sn") or ""),
            raw=data if isinstance(data, dict) else {},
        )

    async def balance(self) -> dict:
        if not self.available():
            return {"supported": True, "ok": False, "message": "Username/API key Digiflazz belum diisi"}
        try:
            data = await self._post("/cek-saldo", {"cmd": "deposit"})
        except VendorError as exc:
            return {"supported": True, "ok": False, "message": str(exc)}
        body = self._data(data)
        return {
            "supported": True,
            "ok": True,
            "balance": body.get("deposit"),
            "message": body.get("message") or "Saldo berhasil diambil",
        }

    async def list_products(self) -> list[PrepaidProduct]:
        if not self.available():
            raise VendorError("Username/API key Digiflazz belum diisi")
        data = await self._post("/price-list", {"cmd": "prepaid", "code": self._cred("brand_override")})
        rows = data.get("data") if isinstance(data, dict) else None
        if not isinstance(rows, list):
            raise VendorError("Format daftar produk Digiflazz tidak dikenali")
        out: list[PrepaidProduct] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            out.append(PrepaidProduct(
                sku=str(row.get("buyer_sku_code") or "").strip(),
                name=str(row.get("product_name") or "").strip(),
                category=str(row.get("category") or "").strip(),
                brand=str(row.get("brand") or "").strip(),
                type=str(row.get("type") or "").strip(),
                seller_name=str(row.get("seller_name") or "").strip(),
                price=int(row.get("price") or 0),
                buyer_product_status=bool(row.get("buyer_product_status", True)),
                seller_product_status=bool(row.get("seller_product_status", True)),
                unlimited_stock=bool(row.get("unlimited_stock", True)),
                stock=int(row.get("stock") or 0),
                multi=bool(row.get("multi", False)),
            ))
        return out

    async def test(self) -> dict:
        result = await self.balance()
        if result.get("ok"):
            return {"ok": True, "message": f"Terhubung. Saldo: {result.get('balance')}", "balance": result.get("balance")}
        return {"ok": False, "message": result.get("message") or "Gagal terhubung"}


class HttpVendor(TopupVendor):
    """Generic HTTP vendor: check ``POST /check``, dispatch ``POST /orders``.

    Used for suppliers other than Digiflazz (VIP Reseller, custom JSON APIs).
    Endpoint paths and the auth header are configurable.
    """

    kind = "http"

    @classmethod
    def describe(cls) -> dict:
        return {
            "kind": "http",
            "label": "Custom HTTP Vendor",
            "description": "Vendor JSON generik: POST /check untuk cek akun dan POST /orders untuk kirim pesanan.",
            "fields": [
                {"key": "base_url", "label": "Base URL", "required": True, "secret": False},
                {"key": "api_key", "label": "API Key", "required": True, "secret": True},
                {"key": "auth_header", "label": "Header API key (default x-api-key)", "required": False, "secret": False},
                {"key": "check_path", "label": "Path cek akun (default /check)", "required": False, "secret": False},
                {"key": "order_path", "label": "Path pesanan (default /orders)", "required": False, "secret": False},
            ],
            "supports": {"check": True, "balance": False, "import": False},
        }

    def available(self) -> bool:
        return bool(self._cred("base_url") and self._cred("api_key"))

    def _headers(self) -> dict:
        header = self._cred("auth_header") or "x-api-key"
        return {header: self._cred("api_key"), "content-type": "application/json", "Accept": "application/json"}

    def _url(self, path_key: str, default: str) -> str:
        base = self._cred("base_url").rstrip("/")
        path = self._cred(path_key) or default
        return f"{base}{path if path.startswith('/') else '/' + path}"

    async def check_account(self, game: Mapping[str, Any], destination: Mapping[str, Any]) -> AccountCheck:
        if not self.available():
            return AccountCheck(checked=False, valid=True, message="Supplier belum dikonfigurasi")
        payload = {"game": game.get("slug") or game.get("id"), "destination": dict(destination)}
        try:
            async with httpx.AsyncClient(timeout=12.0) as http:
                res = await http.post(self._url("check_path", "/check"), json=payload, headers=self._headers())
            res.raise_for_status()
            data = res.json() if res.content else {}
        except (httpx.HTTPError, ValueError) as exc:
            logger.warning("Vendor check failed: %s", exc)
            return AccountCheck(checked=False, valid=True, message="Gagal cek akun, silakan lanjut")
        body = data.get("data") if isinstance(data.get("data"), dict) else data
        valid = bool(body.get("valid", body.get("found", True)))
        return AccountCheck(
            checked=True,
            valid=valid,
            nickname=body.get("nickname") or body.get("name"),
            message=body.get("message") or ("Akun ditemukan" if valid else "Akun tidak ditemukan"),
            raw=data if isinstance(data, dict) else {},
        )

    async def fulfil(self, order: Mapping[str, Any], game: Mapping[str, Any],
                     destination: Mapping[str, Any], product: Mapping[str, Any] | None = None) -> Fulfilment:
        if not self.available():
            return Fulfilment(dispatched=False, message="Supplier belum dikonfigurasi")
        denom = (product or {}).get("denomination") or find_denomination(game, order.get("denomination_code")) or {}
        payload = {
            "reference": order.get("session_id"),
            "game": game.get("slug") or game.get("id"),
            "sku": self.sku_for(game, denom),
            "denomination": order.get("denomination_code"),
            "destination": dict(destination),
        }
        try:
            async with httpx.AsyncClient(timeout=20.0) as http:
                res = await http.post(self._url("order_path", "/orders"), json=payload, headers=self._headers())
            res.raise_for_status()
            data = res.json() if res.content else {}
        except (httpx.HTTPError, ValueError) as exc:
            logger.warning("Vendor fulfil failed for %s: %s", order.get("session_id"), exc)
            return Fulfilment(dispatched=False, message="Vendor gagal, pesanan masuk antrean admin")
        return Fulfilment(
            dispatched=True,
            status=str((data or {}).get("status") or "dispatched"),
            message=str((data or {}).get("message") or "Pesanan dikirim ke vendor"),
            reference=str((data or {}).get("id") or order.get("session_id") or ""),
            sn=str((data or {}).get("sn") or ""),
            raw=data if isinstance(data, dict) else {},
        )

    async def test(self) -> dict:
        if not self.available():
            return {"ok": False, "message": "Base URL dan API key wajib diisi"}
        return {"ok": True, "message": "Konfigurasi lengkap (uji koneksi dilakukan saat cek akun)"}


VENDORS: dict[str, type[TopupVendor]] = {
    ManualVendor.kind: ManualVendor,
    DigiflazzVendor.kind: DigiflazzVendor,
    HttpVendor.kind: HttpVendor,
}

SECRET_KEYS = ("api_key", "dev_key", "token", "secret", "password")


def vendor_catalog() -> list[dict]:
    return [cls.describe() for cls in VENDORS.values()]


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "****"
    return f"{value[:4]}****{value[-4:]}"


def instance_for(doc: Mapping[str, Any] | None) -> TopupVendor:
    if not doc:
        return ManualVendor({})
    kind = str(doc.get("kind") or "manual")
    cls = VENDORS.get(kind, ManualVendor)
    config = {**dict(doc.get("config") or {}), "auto_dispatch": bool(doc.get("auto_dispatch"))}
    return cls(config)


def masked_view(doc: Mapping[str, Any]) -> dict:
    """Admin-facing view: secrets replaced by masks, never sent back in clear."""
    view = dict(doc)
    config = dict(view.get("config") or {})
    for key in list(config.keys()):
        if key in SECRET_KEYS or any(s in key for s in ("key", "secret", "token", "password")):
            config[key] = mask_secret(str(config.get(key) or ""))
    view["config"] = config
    view["kind_label"] = VENDORS.get(str(doc.get("kind")), ManualVendor).describe()["label"]
    return view


async def active_vendor() -> TopupVendor:
    """The vendor used for automatic account checks and dispatching."""
    rows = await topup_providers.find({"is_active": True}, {"_id": 0}).sort("seq", 1).to_list(length=50)
    for row in rows:
        vendor = instance_for(row)
        if vendor.available():
            return vendor
    return ManualVendor({})


async def check_account(game: Mapping[str, Any], destination: Mapping[str, Any]) -> AccountCheck:
    return await (await active_vendor()).check_account(game, destination)


async def fulfil(order: Mapping[str, Any], game: Mapping[str, Any],
                 destination: Mapping[str, Any], product: Mapping[str, Any] | None = None) -> Fulfilment:
    """Dispatch an order to the active supplier, recording the outcome."""
    from db import products

    vendor = await active_vendor()
    if product is None and order.get("product_id"):
        product = await products.find_one({"id": order["product_id"]}, {"_id": 0})
    result = await vendor.fulfil(order, game, destination, product)
    changes = {
        "vendor_kind": vendor.kind,
        "vendor_attempted_at": now_iso(),
        "vendor_status": result.status,
        "vendor_message": (result.message or "")[:500],
    }
    if result.reference:
        changes["provider_order_id"] = result.reference
    if result.sn:
        changes["vendor_sn"] = result.sn
    if result.raw:
        changes["vendor_raw"] = json.loads(json.dumps(result.raw, default=str))
    await transactions.update_one({"session_id": order.get("session_id")}, {"$set": changes})
    return result


def blank_config(kind: str) -> dict:
    cls = VENDORS.get(kind) or ManualVendor
    return {f["key"]: "" for f in cls.describe()["fields"]}


def vendor_by_id_from(docs: list[dict], provider_id: str) -> TopupVendor:
    doc = next((d for d in docs if d.get("id") == provider_id), None)
    if not doc:
        raise VendorError("Supplier tidak ditemukan")
    return instance_for(doc)
