import os
from datetime import datetime, timezone, timedelta

import bcrypt
import jwt
from fastapi import HTTPException, Request

from db import users, login_attempts, now_iso, utcnow

JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALGORITHM = "HS256"
ADMIN_EMAIL = os.environ["ADMIN_EMAIL"].lower()
ADMIN_PASSWORD = os.environ["ADMIN_PASSWORD"]
ADMIN_KEYS = {os.environ.get("ADMIN_KEY", "NEXUS-ADMIN-8888"), "NEXUS-ADMIN-8888"}

MAX_ATTEMPTS = 5
LOCKOUT_MINUTES = 15


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def create_token(user: dict) -> str:
    payload = {
        "sub": user["id"],
        "email": user["email"],
        "role": user.get("role", "buyer"),
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def public_user(user: dict) -> dict:
    return {
        "id": user["id"],
        "email": user["email"],
        "name": user.get("name") or "",
        "role": user.get("role") or "buyer",
        "wishlist": user.get("wishlist") or [],
    }


async def get_user_by_email(email: str):
    return await users.find_one({"email": email}, {"_id": 0})


async def get_user_optional(request: Request):
    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(auth[7:], JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.InvalidTokenError:
        return None
    return await users.find_one({"id": payload.get("sub")}, {"_id": 0})


async def require_user(request: Request) -> dict:
    user = await get_user_optional(request)
    if not user:
        raise HTTPException(status_code=401, detail="Silakan login terlebih dahulu")
    return user


async def require_admin(request: Request) -> dict:
    admin_key = request.headers.get("x-admin-key")
    if admin_key and admin_key in ADMIN_KEYS:
        return {"id": "admin-key", "role": "admin"}
    user = await get_user_optional(request)
    if user and user.get("role") == "admin":
        return user
    raise HTTPException(status_code=401, detail="Akses admin ditolak")


def _attempt_id(request: Request, email: str) -> str:
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0].strip()
    return f"{ip}:{email}"


async def check_lockout(request: Request, email: str):
    rec = await login_attempts.find_one({"identifier": _attempt_id(request, email)})
    if rec and rec.get("locked_until") and rec["locked_until"] > utcnow():
        raise HTTPException(status_code=429, detail="Terlalu banyak percobaan login. Coba lagi dalam 15 menit.")


async def record_failed_login(request: Request, email: str):
    ident = _attempt_id(request, email)
    rec = await login_attempts.find_one_and_update(
        {"identifier": ident},
        {"$inc": {"count": 1}},
        upsert=True,
        return_document=True,
    )
    if rec and (rec.get("count") or 0) >= MAX_ATTEMPTS:
        await login_attempts.update_one(
            {"identifier": ident},
            {"$set": {"count": 0, "locked_until": utcnow() + timedelta(minutes=LOCKOUT_MINUTES)}},
        )


async def clear_login_attempts(request: Request, email: str):
    await login_attempts.delete_one({"identifier": _attempt_id(request, email)})


async def seed_admin():
    existing = await get_user_by_email(ADMIN_EMAIL)
    if existing is None:
        await users.insert_one({
            "id": "admin-master-id",
            "email": ADMIN_EMAIL,
            "password_hash": hash_password(ADMIN_PASSWORD),
            "name": "Admin WillJustPlay",
            "role": "admin",
            "wishlist": [],
            "is_verified": True,
            "created_at": now_iso(),
        })
    elif not verify_password(ADMIN_PASSWORD, existing["password_hash"]):
        await users.update_one({"email": ADMIN_EMAIL}, {"$set": {"password_hash": hash_password(ADMIN_PASSWORD)}})
