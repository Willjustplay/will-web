from dotenv import load_dotenv

load_dotenv()

import os
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from db import init_db, seed_collections
from auth import seed_admin
import routes_auth
import routes_store
import routes_admin
import routes_payments
import routes_topup

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await init_db()
    await seed_collections()
    await seed_admin()
    yield


app = FastAPI(title="WillJustPlay API", lifespan=lifespan)

origins = [o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials="*" not in origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_store.router, prefix="/api")
app.include_router(routes_topup.router, prefix="/api")
app.include_router(routes_auth.router, prefix="/api")
app.include_router(routes_admin.router, prefix="/api")
app.include_router(routes_payments.router, prefix="/api")


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.post("/api/webhook/paykita")
async def paykita_webhook_alias(request: Request):
    return await routes_payments.handle_paykita_webhook(request)


@app.post("/api/webhook/paykita/{product_id}")
async def paykita_product_webhook(product_id: str, request: Request):
    return await routes_payments.handle_paykita_webhook(request, product_id)
