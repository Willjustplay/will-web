"""Public topup endpoints: pick a game, validate the in-game destination and
list the available denominations.

Checkout itself reuses the existing manual/PayKita payment paths in
``routes_payments`` (see ``/payments/topup/checkout``) so stock handling,
admin approval and webhooks stay in one place.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Body

from db import games
from topup_catalog import public_game, validate_destination
from topup_provider import check_account

logger = logging.getLogger("topup")
router = APIRouter(prefix="/topup")


async def get_game_by_slug(slug: str) -> dict:
    game = await games.find_one({"slug": slug}, {"_id": 0})
    if not game:
        raise HTTPException(404, "Game tidak ditemukan")
    if not game.get("is_active", True):
        raise HTTPException(400, "Top up untuk game ini sedang tidak tersedia")
    return game


@router.get("/games")
async def list_games(featured: bool | None = None, q: str | None = None):
    query: dict = {"is_active": True}
    rows = await games.find(query, {"_id": 0}).sort("seq", 1).to_list(length=200)
    items = [public_game(g) for g in rows]
    if featured:
        items = [g for g in items if g.get("featured")]
    if q:
        needle = q.strip().lower()
        items = [
            g for g in items
            if needle in (g.get("name") or "").lower() or needle in (g.get("publisher") or "").lower()
        ]
    return items


@router.get("/games/{slug}")
async def get_game(slug: str):
    return public_game(await get_game_by_slug(slug))


@router.post("/validate")
async def validate_account(body: dict = Body(...)):
    """Validate the game-specific destination fields (User ID / Server / Zone).

    When a topup provider is configured the account is also looked up and the
    nickname returned; otherwise the response is explicitly marked
    ``checked: false`` so the UI never implies an unverified account is valid.
    """
    slug = str(body.get("game") or body.get("slug") or "").strip()
    if not slug:
        raise HTTPException(400, "Game wajib dipilih")
    game = await get_game_by_slug(slug)

    values = body.get("destination")
    if not isinstance(values, dict):
        values = {k: v for k, v in body.items() if k not in ("game", "slug")}

    ok, cleaned, error = validate_destination(game, values)
    if not ok:
        return {"valid": False, "checked": False, "destination": cleaned, "message": error}

    result = await check_account(game, cleaned)
    return {
        "valid": result.valid,
        "checked": result.checked,
        "nickname": result.nickname,
        "destination": cleaned,
        "message": result.message
        or ("Format valid, akun akan diverifikasi admin" if not result.checked else "Akun ditemukan"),
    }


@router.get("/games/{slug}/denominations")
async def list_denominations(slug: str):
    return (public_game(await get_game_by_slug(slug)))["denominations"]
