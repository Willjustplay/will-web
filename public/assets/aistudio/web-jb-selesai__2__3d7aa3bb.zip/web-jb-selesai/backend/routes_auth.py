import os
import logging
from datetime import timedelta
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel, EmailStr

from db import users, verification_tokens, reset_tokens, now_iso, utcnow
from auth import (
    hash_password, verify_password, create_token, public_user, require_user, get_user_by_email,
    check_lockout, record_failed_login, clear_login_attempts, ADMIN_EMAIL,
)
from mailer import (
    send_verification_email,
    send_reset_email,
    is_configured as email_configured,
    mailer_name,
)

logger = logging.getLogger("auth")
router = APIRouter(prefix="/auth")

FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:3000")

# One verification email per address per minute; keeps the endpoint usable for
# real users while making it useless for email bombing.
RESEND_COOLDOWN_SECONDS = 60
_last_resend: dict[str, float] = {}


def _resend_allowed(email: str) -> bool:
    import time

    now = time.time()
    last = _last_resend.get(email, 0)
    if now - last < RESEND_COOLDOWN_SECONDS:
        return False
    _last_resend[email] = now
    return True


class RegisterBody(BaseModel):
    email: EmailStr
    password: str
    name: str | None = ""


class LoginBody(BaseModel):
    email: str
    password: str


class EmailBody(BaseModel):
    email: str


class TokenBody(BaseModel):
    token: str


class ResetBody(BaseModel):
    token: str
    newPassword: str


class AdminPasswordBody(BaseModel):
    password: str


def _origin(request: Request) -> str:
    return FRONTEND_URL


async def _issue_token(collection, email: str, hours: int) -> str:
    token = str(uuid4())
    await collection.insert_one({"token": token, "email": email, "expires_at": utcnow() + timedelta(hours=hours)})
    return token


async def _consume_token(collection, token: str, error: str) -> dict:
    rec = await collection.find_one({"token": token})
    if not rec or rec["expires_at"] < utcnow():
        raise HTTPException(400, error)
    return rec


@router.post("/register")
async def register(body: RegisterBody, request: Request):
    if len(body.password) < 6:
        raise HTTPException(400, "Email dan password minimal 6 karakter dibutuhkan")
    email = body.email.lower().strip()
    if await get_user_by_email(email):
        raise HTTPException(400, "Email sudah terdaftar")

    auto_verify = not email_configured()
    user = {
        "id": str(uuid4()),
        "email": email,
        "password_hash": hash_password(body.password),
        "name": (body.name or "").strip() or email.split("@")[0],
        "role": "buyer",
        "wishlist": [],
        "is_verified": auto_verify,
        "created_at": now_iso(),
    }
    await users.insert_one(user)

    if auto_verify:
        logger.warning("Email not configured; user %s auto-verified", email)
        return {
            "message": "Akun berhasil dibuat. Selamat datang!",
            "email_sent": False,
            "token": create_token(user),
            "user": public_user(user),
        }

    token = await _issue_token(verification_tokens, email, 24)
    verify_url = f"{_origin(request)}/verify-email?token={token}"
    sent = await send_verification_email(email, user["name"], verify_url)
    if not sent:
        # Never leave a user stranded: allow an immediate resend.
        logger.warning("Verification email not sent for %s", email)
        return {
            "message": "Akun berhasil dibuat, tetapi email verifikasi gagal dikirim. Gunakan tombol kirim ulang atau hubungi CS.",
            "email_sent": False,
            "needs_verification": True,
            "email": email,
        }
    return {
        "message": f"Akun berhasil dibuat. Kami sudah mengirim tautan verifikasi ke {email}.",
        "email_sent": True,
        "needs_verification": True,
        "email": email,
        "provider": mailer_name(),
    }

@router.post("/verify-email")
async def verify_email(body: TokenBody):
    rec = await _consume_token(verification_tokens, body.token, "Token verifikasi tidak valid atau sudah kedaluwarsa")
    if not await get_user_by_email(rec["email"]):
        raise HTTPException(404, "User tidak ditemukan")
    await users.update_one({"email": rec["email"]}, {"$set": {"is_verified": True}})
    await verification_tokens.delete_one({"token": body.token})
    return {"message": "Email berhasil diverifikasi. Silakan login."}


@router.post("/resend-verification")
async def resend_verification(body: EmailBody, request: Request):
    email = body.email.lower().strip()
    user = await get_user_by_email(email)
    generic = {"message": "Jika email terdaftar dan belum diverifikasi, tautan baru akan dikirim"}
    if not user or user.get("is_verified"):
        return generic
    if not email_configured():
        raise HTTPException(
            503,
            "Pengiriman email belum dikonfigurasi admin. Hubungi CS via WhatsApp untuk verifikasi manual.",
        )
    if not _resend_allowed(email):
        raise HTTPException(429, "Tunggu sebentar sebelum meminta tautan baru lagi")
    token = await _issue_token(verification_tokens, email, 24)
    sent = await send_verification_email(
        email, user.get("name") or "", f"{_origin(request)}/verify-email?token={token}"
    )
    if not sent:
        logger.warning("Verification email not sent for %s", email)
        raise HTTPException(503, "Gagal mengirim email verifikasi. Coba lagi nanti atau hubungi CS.")
    return {"message": "Email verifikasi baru sudah dikirim. Cek kotak masuk atau spam."}


@router.get("/email-status")
async def email_status():
    """Lets the UI explain whether real verification emails can be delivered."""
    return {
        "configured": email_configured(),
        "provider": mailer_name(),
        "auto_verify": not email_configured(),
    }


@router.post("/login")
async def login(body: LoginBody, request: Request):
    email = body.email.lower().strip()
    if not email or not body.password:
        raise HTTPException(400, "Email dan sandi diperlukan")
    await check_lockout(request, email)
    user = await get_user_by_email(email)
    if not user or not verify_password(body.password, user["password_hash"]):
        await record_failed_login(request, email)
        raise HTTPException(401, "Email atau password salah")
    if not user.get("is_verified"):
        raise HTTPException(403, "Silakan verifikasi email Anda terlebih dahulu. Cek kotak masuk atau spam email Anda.")
    await clear_login_attempts(request, email)
    return {"token": create_token(user), "user": public_user(user)}


@router.post("/admin-login")
async def admin_login(body: AdminPasswordBody, request: Request):
    if not body.password:
        raise HTTPException(400, "Password diperlukan")
    await check_lockout(request, ADMIN_EMAIL)
    user = await users.find_one({"email": ADMIN_EMAIL, "role": "admin"}, {"_id": 0})
    if not user or not verify_password(body.password, user["password_hash"]):
        await record_failed_login(request, ADMIN_EMAIL)
        raise HTTPException(401, "Password admin salah")
    await clear_login_attempts(request, ADMIN_EMAIL)
    return {"token": create_token(user), "user": public_user(user)}


@router.post("/forgot-password")
async def forgot_password(body: EmailBody, request: Request):
    email = body.email.lower().strip()
    if not email:
        raise HTTPException(400, "Email diperlukan")
    generic = {"message": "Jika email terdaftar, tautan reset akan dikirim"}
    user = await get_user_by_email(email)
    if not user:
        return generic
    if not email_configured():
        raise HTTPException(503, "Fitur reset password via email belum aktif. Hubungi admin via WhatsApp untuk bantuan.")
    token = await _issue_token(reset_tokens, email, 1)
    reset_url = f"{_origin(request)}/reset-password?token={token}"
    sent = await send_reset_email(email, user.get("name") or "", reset_url)
    if not sent:
        logger.warning("Reset email not sent. URL: %s", reset_url)
        raise HTTPException(503, "Gagal mengirim email reset. Coba lagi nanti atau hubungi admin.")
    return generic


@router.post("/reset-password")
async def reset_password(body: ResetBody):
    if len(body.newPassword) < 6:
        raise HTTPException(400, "Token dan password baru (min 6 karakter) diperlukan")
    rec = await _consume_token(reset_tokens, body.token, "Token reset password tidak valid atau sudah kedaluwarsa")
    if not await get_user_by_email(rec["email"]):
        raise HTTPException(404, "User tidak ditemukan")
    await users.update_one({"email": rec["email"]}, {"$set": {"password_hash": hash_password(body.newPassword)}})
    await reset_tokens.delete_one({"token": body.token})
    return {"message": "Password berhasil diubah. Silakan login kembali."}


@router.get("/me")
async def me(user: dict = Depends(require_user)):
    return public_user(user)
