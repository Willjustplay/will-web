"""Buyer reviews.

A review is always tied to a paid order. Because order ids (``session_id``) are
short and guessable, submitting one requires proving ownership: either the
request carries the buyer's token, or the buyer email matches the order.

One review per order is enforced by a unique index on ``testimonials.order_id``
(NULL for admin-authored rows, so those stay unconstrained).
"""

from __future__ import annotations

import logging
from uuid import uuid4

from fastapi import HTTPException, Request

from db import products, testimonials, transactions, now_iso

logger = logging.getLogger("reviews")

PUBLIC_REVIEW_PROJECTION = {
    "_id": 0,
    "id": 1,
    "name": 1,
    "rating": 1,
    "text": 1,
    "image": 1,
    "game": 1,
    "product": 1,
    "created_at": 1,
    "source": 1,
    "verified": 1,
    "reply": 1,
}

MIN_REVIEW_LEN = 10
MAX_REVIEW_LEN = 600
MAX_IMAGE_LEN = 2_000_000


def public_review(row: dict) -> dict:
    """Shape a testimonial for public consumption (never leaks buyer_email)."""
    rating = int(row.get("rating") or 5)
    return {
        "id": row.get("id"),
        "name": row.get("name") or "Pembeli",
        "rating": max(1, min(5, rating)),
        "text": row.get("text") or "",
        "image": row.get("image") or "",
        "game": row.get("game") or "",
        "product": row.get("product") or "",
        "created_at": row.get("created_at") or "",
        "source": row.get("source") or "admin",
        "verified": bool(row.get("verified")),
        "reply": row.get("reply") or "",
    }


def public_reviewer_name(user: dict | None, email: str | None) -> str:
    """Public display name: account name, else the (masked) email local part."""
    name = ((user or {}).get("name") or "").strip()
    if name:
        return name
    local = (email or "").split("@")[0].strip()
    if not local:
        return "Pembeli"
    # Keep it recognisable without publishing a full email address.
    cleaned = "".join(ch for ch in local if ch.isalnum() or ch in "._-")
    return cleaned[:24] or "Pembeli"


async def _existing_review(order_id: str) -> dict | None:
    return await testimonials.find_one({"order_id": order_id}, {"_id": 0})


async def _order_for_review(session_id: str) -> dict:
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0, "payment_proof": 0})
    if not tx:
        raise HTTPException(404, "Pesanan tidak ditemukan")
    return tx


def _authorized(tx: dict, user: dict | None, email: str | None) -> bool:
    if user and tx.get("user_id") and tx["user_id"] == user.get("id"):
        return True
    try:
        given = (email or "").strip().lower()
    except AttributeError:
        given = ""
    stored = (tx.get("buyer_email") or "").strip().lower()
    return bool(given and stored and given == stored)


async def review_eligibility(session_id: str, user: dict | None, email: str | None) -> dict:
    tx = await _order_for_review(session_id)
    paid = tx.get("payment_status") == "paid"
    authorized = _authorized(tx, user, email)
    existing = await _existing_review(session_id) if paid else None
    reason = ""
    if not paid:
        reason = "Ulasan hanya bisa ditulis setelah pesanan lunas"
    elif not authorized:
        reason = "Verifikasi diperlukan: masukkan email yang dipakai saat membeli"
    return {
        "can_review": bool(paid and authorized and not existing),
        "authorized": authorized,
        "paid": paid,
        "has_review": bool(existing),
        "reason": reason,
        "order": {
            "session_id": tx.get("session_id"),
            "product_id": tx.get("product_id"),
            "product_title": tx.get("product_title"),
            "game": tx.get("game_name") or "",
        },
        "review": public_review(existing) if existing else None,
    }


async def refresh_product_rating(product_id: str) -> int:
    """Recompute a product's rating/average from its verified reviews.

    With no reviews left, ``rating`` falls back to ``rating_base`` (the value the
    catalogue shipped with) so cards never show a stale average.
    """
    if not product_id:
        return 0
    rows = await testimonials.find(
        {"product_id": product_id, "verified": True}, {"_id": 0, "rating": 1}
    ).to_list(length=1000)
    product = await products.find_one({"id": product_id}, {"_id": 0, "rating": 1, "rating_base": 1})
    if not rows:
        base = (product or {}).get("rating_base")
        if base is None:
            base = (product or {}).get("rating", 5.0)
        await products.update_one(
            {"id": product_id},
            {"$set": {"rating": float(base or 5.0), "review_count": 0}},
        )
        return 0
    ratings = [max(1, min(5, int(r.get("rating") or 5))) for r in rows]
    average = round(sum(ratings) / len(ratings), 1)
    await products.update_one(
        {"id": product_id},
        {"$set": {"rating": average, "review_count": len(ratings)}},
    )
    return len(ratings)


async def submit_review(request: Request, body: dict) -> dict:
    session_id = str(body.get("session_id") or body.get("order_id") or "").strip()
    if not session_id:
        raise HTTPException(400, "Kode pesanan wajib diisi")

    tx = await _order_for_review(session_id)
    if tx.get("payment_status") != "paid":
        raise HTTPException(400, "Ulasan hanya bisa ditulis setelah pesanan lunas")

    from auth import get_user_optional

    user = await get_user_optional(request)
    email = str(body.get("buyer_email") or "").strip()
    if not _authorized(tx, user, email):
        raise HTTPException(403, "Email tidak cocok dengan pesanan ini. Masuk ke akun atau cek email pembelian.")

    if await _existing_review(session_id):
        raise HTTPException(409, "Pesanan ini sudah pernah diulas")

    try:
        rating = int(body.get("rating"))
    except (TypeError, ValueError):
        raise HTTPException(400, "Rating wajib diisi (1-5)")
    if not 1 <= rating <= 5:
        raise HTTPException(400, "Rating harus antara 1 sampai 5")

    text = str(body.get("text") or "").strip()
    if len(text) < MIN_REVIEW_LEN:
        raise HTTPException(400, f"Ulasan minimal {MIN_REVIEW_LEN} karakter")
    if len(text) > MAX_REVIEW_LEN:
        raise HTTPException(400, f"Ulasan maksimal {MAX_REVIEW_LEN} karakter")

    image = str(body.get("image") or "").strip()
    if len(image) > MAX_IMAGE_LEN:
        raise HTTPException(400, "Ukuran lampiran terlalu besar")

    product = await products.find_one({"id": tx.get("product_id")}, {"_id": 0}) if tx.get("product_id") else None
    review = {
        "id": "rv-" + uuid4().hex[:10],
        "order_id": session_id,
        "product_id": tx.get("product_id"),
        "user_id": tx.get("user_id") or (user.get("id") if user else None),
        "name": public_reviewer_name(user, tx.get("buyer_email") or email),
        "buyer_email": (tx.get("buyer_email") or email or "").strip().lower(),
        "game": tx.get("game_name") or (product or {}).get("game") or "",
        "product": tx.get("product_title") or (product or {}).get("title") or "",
        "rating": rating,
        "text": text,
        "image": image,
        "source": "buyer",
        "verified": True,
        "reply": "",
        "created_at": now_iso(),
    }
    try:
        await testimonials.insert_one(dict(review))
    except Exception as exc:  # noqa: BLE001 - unique index on order_id
        message = str(exc).lower()
        if "unique" in message or "duplicate" in message or "integrity" in message:
            raise HTTPException(409, "Pesanan ini sudah pernah diulas") from exc
        raise

    if tx.get("product_id"):
        await refresh_product_rating(tx["product_id"])
    return {"message": "Terima kasih! Ulasan kamu sudah tayang.", "review": public_review(review)}
