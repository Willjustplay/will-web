"""Topup catalogue helpers.

Each active denomination of a game is mirrored into a regular ``products`` row
so that stock handling, manual/PayKita checkout, admin approval, order history
and webhooks all work unchanged. The internal product id is deterministic:

    topup-<game-slug>-<denomination-code>

Topup orders never carry an in-game account in the product; the destination
(User ID / Server) lives on the transaction itself, recorded by the checkout
endpoint from :mod:`routes_topup`.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping

from db import games, products, now_iso

TOPUP_CATEGORY = "Topup Game"
PRODUCT_TYPE = "topup"
ID_SAFE = re.compile(r"[^a-z0-9]+")


def product_id_for(slug: str, code: str) -> str:
    return f"topup-{_slugify(slug)}-{_slugify(code)}"


def _slugify(value: str) -> str:
    return ID_SAFE.sub("-", str(value or "").lower()).strip("-")


def find_denomination(game: Mapping[str, Any], code: str) -> dict | None:
    for denom in game.get("denominations") or []:
        if str(denom.get("code")) == str(code):
            return denom
    return None


def active_denominations(game: Mapping[str, Any]) -> list[dict]:
    rows = [d for d in (game.get("denominations") or []) if d.get("is_active", True)]
    return sorted(rows, key=lambda d: (d.get("seq") or 0, str(d.get("code"))))


def denomination_product(game: Mapping[str, Any], denom: Mapping[str, Any]) -> dict:
    """Build the catalogue product that backs one denomination."""
    slug = game.get("slug") or game.get("id")
    code = str(denom.get("code"))
    stock = denom.get("stock")
    badges = [b for b in [denom.get("badge")] if b]
    if game.get("currency"):
        badges.append(f"{game['currency']} Instan")
    return {
        "id": product_id_for(slug, code),
        "game": game.get("name"),
        "category": TOPUP_CATEGORY,
        "product_type": PRODUCT_TYPE,
        "slug": slug,
        "game_id": game.get("id"),
        "denomination_code": code,
        "denomination": {
            "code": code,
            "label": denom.get("label"),
            "amount": denom.get("amount"),
            "price_strike": denom.get("price_strike"),
        },
        "title": f"{game.get('name')} — {denom.get('label') or code}",
        "price": int(denom.get("price") or 0),
        "price_strike": denom.get("price_strike"),
        "rank": "Via ID Server",
        "image": game.get("banner") or game.get("icon") or "",
        "images": [],
        "stock": int(stock if stock is not None else 999),
        "badge": badges[0] if badges else "",
        "badges": badges[:3],
        "featured": bool(denom.get("featured", False)),
        "sold": int(denom.get("sold") or 0),
        "rating": float(denom.get("rating") or 4.9),
        "rating_base": float(denom.get("rating") or 4.9),
        "condition": "ready",
        "seq": denom.get("seq") or 0,
        "warranty": "100%",
        "delivery_info": game.get("delivery_info") or "Item masuk otomatis setelah pembayaran terverifikasi",
        "description": (
            f"Top up {denom.get('label') or code} untuk {game.get('name')} "
            f"({game.get('publisher') or ''}). Proses instan via User ID & Server, "
            f"legal 100% tanpa login akun."
        ).strip(),
        "created_at": now_iso(),
    }


async def sync_game_products(game: Mapping[str, Any], replace: bool = True) -> int:
    """Mirror every active denomination of ``game`` into ``products``.

    Deactivates (deletes) products whose denomination was removed or disabled,
    so the catalogue always matches the game definition. Returns the number of
    products written.
    """
    slug = game.get("slug") or game.get("id")
    existing = await products.find({"slug": slug, "product_type": PRODUCT_TYPE}, {"_id": 0}).to_list(length=500)
    by_code = {str(row.get("denomination_code")): row for row in existing}
    written = 0
    keep: set[str] = set()

    for denom in active_denominations(game):
        product = denomination_product(game, denom)
        keep.add(product["id"])
        prior = by_code.get(str(denom.get("code")))
        if prior:
            # Preserve stats that are only tracked on the product row.
            product["sold"] = int(prior.get("sold") or product["sold"])
            product["rating"] = float(prior.get("rating") or product["rating"])
            product["rating_base"] = float(prior.get("rating_base") or product["rating_base"])
            product["created_at"] = prior.get("created_at") or product["created_at"]
            await products.update_one(
                {"id": product["id"]},
                {"$set": {k: v for k, v in product.items() if k != "id"}},
            )
        else:
            await products.insert_one(dict(product))
        written += 1

    if replace:
        for row in existing:
            if row.get("id") not in keep:
                await products.delete_one({"id": row["id"]})
    return written


async def sync_all_games(replace: bool = True) -> int:
    rows = await games.find({}, {"_id": 0}).to_list(length=500)
    total = 0
    for game in rows:
        total += await sync_game_products(game, replace=replace)
    return total


def _norm_game(game: Mapping[str, Any] | None) -> dict | None:
    if not game:
        return None
    return dict(game)


def public_game(game: Mapping[str, Any]) -> dict:
    """Trim a game document for public consumption (hide admin-only settings)."""
    game = _norm_game(game) or {}
    denominations = [
        {
            "code": str(d.get("code")),
            "label": d.get("label"),
            "amount": d.get("amount"),
            "price": int(d.get("price") or 0),
            "price_strike": d.get("price_strike"),
            "stock": int(d.get("stock") if d.get("stock") is not None else 999),
            "badge": d.get("badge") or "",
            "seq": d.get("seq") or 0,
        }
        for d in active_denominations(game)
        if int(d.get("price") or 0) > 0
    ]
    return {
        "id": game.get("id"),
        "slug": game.get("slug"),
        "name": game.get("name"),
        "publisher": game.get("publisher") or "",
        "icon": game.get("icon") or "",
        "banner": game.get("banner") or "",
        "currency": game.get("currency") or "Item",
        "notes": game.get("notes") or "",
        "delivery_info": game.get("delivery_info") or "",
        "seq": game.get("seq") or 0,
        "featured": bool(game.get("featured", False)),
        "fields": list(game.get("fields") or []),
        "denominations": denominations,
        "min_price": min((d["price"] for d in denominations), default=0),
        "max_price": max((d["price"] for d in denominations), default=0),
    }


def validate_destination(game: Mapping[str, Any], values: Mapping[str, Any]) -> tuple[bool, dict, str]:
    """Validate the in-game destination against the game's declared fields.

    Returns ``(ok, cleaned_values, error_message)``.
    """
    cleaned: dict[str, Any] = {}
    for field in game.get("fields") or []:
        key = field.get("key")
        if not key:
            continue
        raw = str(values.get(key, "") or "").strip()
        label = field.get("label") or key
        if not raw:
            if field.get("required", True):
                return False, cleaned, f"{label} wajib diisi"
            cleaned[key] = ""
            continue
        min_len = int(field.get("min_len") or 0)
        max_len = int(field.get("max_len") or 0)
        if min_len and len(raw) < min_len:
            return False, cleaned, f"{label} minimal {min_len} karakter"
        if max_len and len(raw) > max_len:
            return False, cleaned, f"{label} maksimal {max_len} karakter"
        pattern = field.get("pattern")
        if pattern:
            try:
                if not re.match(pattern, raw):
                    return False, cleaned, field.get("help") or f"Format {label} tidak valid"
            except re.error:  # malformed admin-provided pattern: skip the check
                pass
        cleaned[key] = raw
    if not cleaned:
        return False, cleaned, "Game ini belum dikonfigurasi tujuan top up-nya"
    return True, cleaned, ""


def destination_label(game: Mapping[str, Any] | None, destination: Mapping[str, Any] | None) -> str:
    if not destination:
        return ""
    labels = {f.get("key"): (f.get("label") or f.get("key")) for f in (game or {}).get("fields") or []}
    parts = [f"{labels.get(k, k)}: {v}" for k, v in destination.items() if v]
    return " • ".join(parts)


def render_delivery_info(product: Mapping[str, Any], game: Mapping[str, Any] | None,
                         destination: Mapping[str, Any] | None) -> str:
    """Delivery text shown to the buyer once a topup order is paid."""
    base = (product.get("delivery_info") or "").strip() if product else ""
    if not base:
        base = (game or {}).get("delivery_info") or "Item akan dikirim setelah pembayaran terverifikasi"
    label = destination_label(game, destination)
    parts: Iterable[str] = [part for part in (base, f"Tujuan: {label}" if label else "") if part]
    return " — ".join(parts)
