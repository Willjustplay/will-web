"""Database bootstrap.

Selects the storage backend from ``DB_BACKEND`` and exposes the collections the
rest of the application imports:

    mariadb (default)  SQLAlchemy Core over aiomysql
    mongo              the original motor/MongoDB setup
    sqlite             SQLAlchemy Core over aiosqlite (local dev and tests)

For the SQL backends every collection is served by ``docstore`` and keeps a
Mongo-like asynchronous API, so route code is identical across backends.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

MONGO_URL = os.environ.get("MONGO_URL", "mongodb://127.0.0.1:27017")
DB_NAME = os.environ.get("DB_NAME", "willjustplay")
BACKEND = (os.environ.get("DB_BACKEND") or "mariadb").strip().lower()

SEED = json.loads((Path(__file__).parent / "seed_data.json").read_text())

SEED_MANUAL_DESTINATIONS = [
    {
        "id": "mp-qris-demo",
        "type": "qris",
        "name": "QRIS",
        "account_name": "WillJustPlay",
        "account_number": "-",
        "image": "https://placehold.co/400x400/png?text=QRIS+Placeholder",
        "is_active": True,
        "seq": 0,
    },
    {
        "id": "mp-bca-demo",
        "type": "bank",
        "name": "BCA",
        "account_name": "Will Business",
        "account_number": "1234567890",
        "image": "",
        "is_active": True,
        "seq": 1,
    },
]

SEED_SOCIAL_LINKS = [
    {
        "id": "sl-facebook-demo",
        "platform": "facebook",
        "name": "Facebook",
        "url": "https://www.facebook.com/share/1Ey74rNDVi/",
        "is_active": True,
        "seq": 0,
    },
    {
        "id": "sl-whatsapp-demo",
        "platform": "whatsapp",
        "name": "WhatsApp",
        "url": "https://wa.me/6285693161480",
        "is_active": True,
        "seq": 1,
    },
]

COLLECTIONS = (
    "users",
    "products",
    "games",
    "testimonials",
    "transactions",
    "manual_destinations",
    "files",
    "verification_tokens",
    "reset_tokens",
    "login_attempts",
    "settings",
    "social_links",
    "topup_providers",
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def clean(doc):
    if doc is None:
        return None
    doc = dict(doc)
    doc.pop("_id", None)
    return doc


def _sqlalchemy_url() -> str:
    if BACKEND == "sqlite":
        path = os.environ.get("SQLITE_PATH", "./dev.sqlite3")
        if path.startswith(":memory:"):
            return "sqlite+aiosqlite:///:memory:"
        return f"sqlite+aiosqlite:///{Path(path).as_posix()}"
    url = os.environ.get("MARIADB_URL")
    if url:
        return url
    host = os.environ.get("DB_HOST", "127.0.0.1")
    port = os.environ.get("DB_PORT", "3306")
    user = os.environ.get("DB_USER", "root")
    password = os.environ.get("DB_PASSWORD", "")
    name = os.environ.get("DB_NAME", DB_NAME)
    credentials = f"{user}:{password}" if password else user
    return f"mysql+aiomysql://{credentials}@{host}:{port}/{name}"


if BACKEND == "mongo":
    from motor.motor_asyncio import AsyncIOMotorClient

    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    store = None
    engine = None
    session_factory = None
    _COLLECTIONS = {name: db[name] for name in COLLECTIONS}
else:
    from docstore import SQLDocumentStore

    client = None
    db = None
    engine = create_async_engine(_sqlalchemy_url(), pool_pre_ping=True, pool_recycle=280)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    store = SQLDocumentStore(engine)
    _COLLECTIONS = store.collections

users = _COLLECTIONS["users"]
products = _COLLECTIONS["products"]
games = _COLLECTIONS["games"]
testimonials = _COLLECTIONS["testimonials"]
transactions = _COLLECTIONS["transactions"]
manual_destinations = _COLLECTIONS["manual_destinations"]
files = _COLLECTIONS["files"]
verification_tokens = _COLLECTIONS["verification_tokens"]
reset_tokens = _COLLECTIONS["reset_tokens"]
login_attempts = _COLLECTIONS["login_attempts"]
settings = _COLLECTIONS["settings"]
social_links = _COLLECTIONS["social_links"]
topup_providers = _COLLECTIONS["topup_providers"]


async def init_db():
    """Create schema (SQL) or indexes (Mongo) for every collection."""
    if store is not None:
        await store.create_all()
        return
    from pymongo import ASCENDING

    _ = ASCENDING
    await users.create_index("email", unique=True)
    await users.create_index("id", unique=True)
    await products.create_index("id", unique=True)
    await games.create_index("slug", unique=True)
    await transactions.create_index("session_id", unique=True)
    await manual_destinations.create_index("id", unique=True)
    await verification_tokens.create_index("token", unique=True)
    await reset_tokens.create_index("token", unique=True)
    await verification_tokens.create_index("expires_at", expireAfterSeconds=0)
    await reset_tokens.create_index("expires_at", expireAfterSeconds=0)
    await login_attempts.create_index("identifier", unique=True)
    await files.create_index("path", unique=True)
    await social_links.create_index("id", unique=True)
    # Sparse + unique: admin-authored testimonials carry no order_id.
    await testimonials.create_index("order_id", unique=True, sparse=True)


async def seed_collections():
    from topup_catalog import sync_game_products

    if await products.count_documents({"product_type": {"$ne": "topup"}}) == 0:
        legacy = [p for p in SEED["SEED_PRODUCTS"] if p.get("category") != "Topup Game"]
        if legacy:
            await products.insert_many([dict(p) for p in legacy])
    if await games.count_documents({}) == 0:
        await games.insert_many([dict(g) for g in SEED.get("SEED_GAMES", [])])
    for game in SEED.get("SEED_GAMES", []):
        await sync_game_products(game, replace=False)
    if await testimonials.count_documents({}) == 0:
        await testimonials.insert_many([dict(t) for t in SEED["SEED_TESTIMONIALS"]])
    if await manual_destinations.count_documents({}) == 0:
        await manual_destinations.insert_many([dict(d) for d in SEED_MANUAL_DESTINATIONS])
    if await social_links.count_documents({}) == 0:
        await social_links.insert_many([dict(s) for s in SEED_SOCIAL_LINKS])
    if await topup_providers.count_documents({}) == 0:
        await topup_providers.insert_one({
            "id": "vp-manual",
            "kind": "manual",
            "name": "Manual (Admin)",
            "config": {},
            "is_active": True,
            "auto_dispatch": False,
            "seq": 0,
            "created_at": now_iso(),
        })


async def seed_products_force() -> int:
    """Reset catalogue products to the seed state (legacy products + topup products)."""
    from topup_catalog import sync_game_products

    await products.delete_many({})
    legacy = [p for p in SEED["SEED_PRODUCTS"] if p.get("category") != "Topup Game"]
    if legacy:
        await products.insert_many([dict(p) for p in legacy])
    for game in SEED.get("SEED_GAMES", []):
        await sync_game_products(game, replace=False)
    return await products.count_documents({})


# --- PayKita settings helpers ---
async def get_paykita_settings() -> dict:
    doc = await settings.find_one({"id": "paykita"}, {"_id": 0})
    if not doc:
        doc = {
            "id": "paykita",
            "api_key": "",
            "webhook_secret": "",
            "base_url": "https://pay.digikita.id",
            "enabled": False,
        }
    doc.setdefault("base_url", "https://pay.digikita.id")
    doc.setdefault("enabled", False)
    return doc
