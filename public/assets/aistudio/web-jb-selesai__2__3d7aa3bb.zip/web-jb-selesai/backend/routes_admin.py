import os
import re
import time
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Depends, Body, UploadFile, File

from db import (
    products, testimonials, transactions, manual_destinations, files, settings, social_links,
    games, topup_providers, now_iso, clean, get_paykita_settings,
)
from auth import require_admin
from routes_payments import paykita_creds, paykita_call, _extract_paykita, sync_paykita
from topup_catalog import public_game, sync_game_products, sync_all_games
from topup_provider import fulfil
from reviews import refresh_product_rating
from topup_vendors import (
    ManualVendor,
    VENDORS,
    VendorError,
    active_vendor,
    instance_for,
    mask_secret,
    masked_view,
    vendor_catalog,
)

router = APIRouter(prefix="/admin", dependencies=[Depends(require_admin)])

ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_UPLOAD = 5 * 1024 * 1024
FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:3000")


def _masked(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "****"
    return key[:8] + "****" + key[-4:]


def _admin_view(p: dict) -> dict:
    pk = p.pop("paykita", None) or {}
    p["paykita_api_key_set"] = bool(pk.get("api_key"))
    p["paykita_api_key_masked"] = _masked(pk.get("api_key", ""))
    p["paykita_webhook_secret_set"] = bool(pk.get("webhook_secret"))
    p["paykita_webhook_url"] = f"{FRONTEND_URL}/api/webhook/paykita/{p['id']}"
    return p


def _product_paykita(data: dict, existing: dict | None = None) -> dict:
    cur = dict(existing or {})
    inc = data.get("paykita")
    if not isinstance(inc, dict):
        return cur
    if inc.get("clear"):
        return {}
    for k in ("api_key", "webhook_secret"):
        if isinstance(inc.get(k), str) and inc[k].strip():
            cur[k] = inc[k].strip()
    return cur


@router.get("/verify")
async def verify_admin():
    return {"ok": True}


@router.get("/products")
async def admin_products():
    rows = await products.find({}, {"_id": 0}).to_list(length=1000)
    return [_admin_view(p) for p in rows]


def _num(v, default, cast=float):
    try:
        return cast(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


@router.post("/products")
async def create_product(data: dict = Body(...)):
    if not (data.get("title") or "").strip() or not (data.get("game") or "").strip():
        raise HTTPException(400, "Judul dan nama game wajib diisi")
    product = {
        **data,
        "id": str(uuid4())[:8],
        "images": [i for i in (data.get("images") or []) if i][:5],
        "badges": [b for b in (data.get("badges") or []) if b][:3],
        "sold": _num(data.get("sold"), 0, int),
        "rating": _num(data.get("rating"), 5.0),
        "rating_base": _num(data.get("rating"), 5.0),
        "stock": _num(data.get("stock"), 1, int),
        "price": _num(data.get("price"), 0, int),
        "paykita": _product_paykita(data),
        "created_at": now_iso(),
    }
    product.pop("_id", None)
    await products.insert_one(dict(product))
    return _admin_view(clean(product))


@router.put("/products/{product_id}")
async def update_product(product_id: str, data: dict = Body(...)):
    existing = await products.find_one({"id": product_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Produk tidak ditemukan")
    data.pop("_id", None)
    data.pop("id", None)
    images = data["images"] if "images" in data else existing.get("images")
    badges = data["badges"] if "badges" in data else existing.get("badges")
    updated = {
        **existing,
        **data,
        "images": [i for i in (images or []) if i][:5],
        "badges": [b for b in (badges or []) if b][:3],
        "sold": _num(data.get("sold"), existing.get("sold", 0), int),
        "rating": _num(data.get("rating"), existing.get("rating", 5.0)),
        "rating_base": _num(data.get("rating"), existing.get("rating_base", 5.0)),
        "stock": _num(data.get("stock"), existing.get("stock", 1), int),
        "price": _num(data.get("price"), existing.get("price", 0), int),
        "paykita": _product_paykita(data, existing.get("paykita")),
        "updated_at": now_iso(),
        "id": product_id,
    }
    await products.update_one({"id": product_id}, {"$set": {k: v for k, v in updated.items() if k != "id"}})
    return _admin_view(updated)


@router.delete("/products/{product_id}")
async def delete_product(product_id: str):
    res = await products.delete_one({"id": product_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Produk tidak ditemukan")
    return {"ok": True}


@router.post("/reset")
async def reset_products():
    from db import seed_products_force
    count = await seed_products_force()
    return {"ok": True, "count": count}


@router.get("/orders")
async def list_orders():
    orders = await transactions.find(
        {}, {"_id": 0, "payment_proof": 0}
    ).sort("created_at", -1).to_list(length=2000)
    for o in orders:
        o["has_proof"] = bool(o.get("has_proof"))
    return orders


@router.get("/orders/{session_id}/proof")
async def order_proof(session_id: str):
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0, "payment_proof": 1})
    if not tx or not tx.get("payment_proof"):
        raise HTTPException(404, "Bukti pembayaran belum diupload")
    return {"payment_proof": tx["payment_proof"]}


async def _manual_tx(session_id: str):
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx or tx.get("provider") != "manual":
        raise HTTPException(404, "Transaksi manual tidak ditemukan")
    return tx


@router.post("/orders/{session_id}/approve")
async def approve_order(session_id: str):
    tx = await _manual_tx(session_id)
    if tx.get("payment_status") == "paid":
        return tx
    changes = {"status": "completed", "payment_status": "paid", "updated_at": now_iso()}
    if not tx.get("stock_deducted"):
        await products.update_one({"id": tx["product_id"], "stock": {"$gt": 0}}, {"$inc": {"stock": -1}})
        await products.update_one({"id": tx["product_id"]}, {"$inc": {"sold": 1}})
        changes["stock_deducted"] = True
    await transactions.update_one({"session_id": session_id}, {"$set": changes})
    return {**tx, **changes}


@router.post("/orders/{session_id}/reject")
async def reject_order(session_id: str):
    tx = await _manual_tx(session_id)
    if tx.get("payment_status") == "paid":
        raise HTTPException(400, "Pesanan yang sudah lunas tidak bisa ditolak")
    changes = {"status": "rejected", "payment_status": "failed", "updated_at": now_iso()}
    await transactions.update_one({"session_id": session_id}, {"$set": changes})
    return {**tx, **changes}


@router.get("/orders/{session_id}")
async def get_order(session_id: str):
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx:
        raise HTTPException(404, "Transaksi tidak ditemukan")
    return tx


@router.post("/testimonials")
async def create_testimonial(data: dict = Body(...)):
    if not (data.get("name") or "").strip() or not (data.get("text") or "").strip():
        raise HTTPException(400, "Nama dan isi ulasan wajib diisi")
    testimonial = {
        **data,
        "id": str(uuid4())[:8],
        "rating": max(1, min(5, _num(data.get("rating"), 5, int))),
        "source": "admin",
        "verified": bool(data.get("verified", False)),
        "created_at": now_iso(),
    }
    testimonial.pop("_id", None)
    await testimonials.insert_one(dict(testimonial))
    return clean(testimonial)


@router.delete("/testimonials/{tid}")
async def delete_testimonial(tid: str):
    existing = await testimonials.find_one({"id": tid}, {"_id": 0})
    res = await testimonials.delete_one({"id": tid})
    if res.deleted_count == 0:
        raise HTTPException(404, "Testimoni tidak ditemukan")
    # Keep the product rating in sync when a review is removed.
    if existing and existing.get("product_id"):
        await refresh_product_rating(existing["product_id"])
    return {"ok": True}


# --- Buyer reviews (moderation) ---
@router.get("/reviews")
async def list_reviews(source: str | None = None, rating: int | None = None,
                       product_id: str | None = None, q: str | None = None):
    query: dict = {}
    if source:
        query["source"] = source
    if rating:
        query["rating"] = int(rating)
    if product_id:
        query["product_id"] = product_id
    rows = await testimonials.find(query, {"_id": 0}).sort("created_at", -1).to_list(length=1000)
    if q:
        needle = q.strip().lower()
        rows = [
            r for r in rows
            if needle in (r.get("text") or "").lower()
            or needle in (r.get("name") or "").lower()
            or needle in (r.get("product") or "").lower()
        ]
    summary = {
        "total": len(rows),
        "buyer": sum(1 for r in rows if (r.get("source") or "admin") == "buyer"),
        "admin": sum(1 for r in rows if (r.get("source") or "admin") == "admin"),
        "average": round(sum(int(r.get("rating") or 5) for r in rows) / len(rows), 1) if rows else 0,
    }
    return {"summary": summary, "reviews": rows}


@router.post("/reviews/{review_id}/reply")
async def reply_review(review_id: str, data: dict = Body(...)):
    existing = await testimonials.find_one({"id": review_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Ulasan tidak ditemukan")
    reply = (data.get("reply") or "").strip()
    if len(reply) > 600:
        raise HTTPException(400, "Balasan maksimal 600 karakter")
    await testimonials.update_one(
        {"id": review_id},
        {"$set": {"reply": reply, "replied_at": now_iso()}},
    )
    return {**existing, "reply": reply}


@router.delete("/reviews/{review_id}")
async def delete_review(review_id: str):
    existing = await testimonials.find_one({"id": review_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Ulasan tidak ditemukan")
    await testimonials.delete_one({"id": review_id})
    if existing.get("product_id"):
        await refresh_product_rating(existing["product_id"])
    return {"message": "Ulasan dihapus"}


# --- Topup suppliers (Digiflazz, custom HTTP vendors, ...) ---
def _provider_payload(data: dict, existing: dict | None = None) -> dict:
    base = dict(existing or {})
    kind = (data.get("kind") or base.get("kind") or "manual").strip().lower()
    if kind not in VENDORS:
        raise HTTPException(400, f"Supplier tidak dikenal: {kind}")
    spec = {f["key"] for f in VENDORS[kind].describe()["fields"]}

    # Merge config, keeping stored secrets when the client sends a masked value.
    current = dict(base.get("config") or {})
    incoming = data.get("config") if isinstance(data.get("config"), dict) else {}
    config = dict(current)
    for key in spec:
        if key not in incoming:
            continue
        value = incoming[key]
        if isinstance(value, str):
            if "*" in value and value == mask_secret(str(current.get(key) or "")):
                continue  # unchanged masked secret
            config[key] = value.strip()
        else:
            config[key] = value
    for key in list(config.keys()):
        if key not in spec:
            config.pop(key)

    name = (data.get("name") or base.get("name") or VENDORS[kind].describe()["label"]).strip()
    return {
        **base,
        "id": base.get("id") or f"vp-{kind}-{uuid4().hex[:6]}",
        "kind": kind,
        "name": name,
        "config": config,
        "is_active": bool(data.get("is_active", base.get("is_active", True))),
        "auto_dispatch": bool(data.get("auto_dispatch", base.get("auto_dispatch", False))),
        "seq": _num(data.get("seq"), base.get("seq", 0), int),
        "created_at": base.get("created_at") or now_iso(),
        "updated_at": now_iso(),
    }


@router.get("/topup/vendors/catalog")
async def vendor_catalog_endpoint():
    return vendor_catalog()


@router.get("/topup/vendors")
async def list_vendors():
    rows = await topup_providers.find({}, {"_id": 0}).sort("seq", 1).to_list(length=100)
    active = await active_vendor()
    return {
        "vendors": [masked_view(r) for r in rows],
        "active_kind": active.kind,
        "active_label": VENDORS.get(active.kind, ManualVendor).describe()["label"],
    }


@router.post("/topup/vendors", status_code=201)
async def create_vendor(data: dict = Body(...)):
    payload = _provider_payload(data)
    await topup_providers.insert_one(dict(payload))
    return masked_view(payload)


@router.put("/topup/vendors/{provider_id}")
async def update_vendor(provider_id: str, data: dict = Body(...)):
    existing = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Supplier tidak ditemukan")
    data.pop("_id", None)
    payload = _provider_payload({**data, "id": None}, existing)
    await topup_providers.update_one(
        {"id": provider_id}, {"$set": {k: v for k, v in payload.items() if k != "id"}}
    )
    return masked_view(payload)


@router.delete("/topup/vendors/{provider_id}")
async def delete_vendor(provider_id: str):
    res = await topup_providers.delete_one({"id": provider_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Supplier tidak ditemukan")
    return {"ok": True}


@router.post("/topup/vendors/{provider_id}/activate")
async def activate_vendor(provider_id: str):
    existing = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Supplier tidak ditemukan")
    await topup_providers.update_one({"id": provider_id}, {"$set": {"is_active": True}})
    return {"ok": True, "active_kind": existing.get("kind")}


@router.post("/topup/vendors/{provider_id}/deactivate")
async def deactivate_vendor(provider_id: str):
    existing = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Supplier tidak ditemukan")
    await topup_providers.update_one({"id": provider_id}, {"$set": {"is_active": False}})
    return {"ok": True}


@router.post("/topup/vendors/{provider_id}/test")
async def test_vendor(provider_id: str):
    doc = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Supplier tidak ditemukan")
    try:
        result = await instance_for(doc).test()
    except VendorError as exc:
        result = {"ok": False, "message": str(exc)}
    await topup_providers.update_one(
        {"id": provider_id}, {"$set": {"last_test": {**result, "at": now_iso()}}}
    )
    return result


@router.get("/topup/vendors/{provider_id}/balance")
async def vendor_balance(provider_id: str):
    doc = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Supplier tidak ditemukan")
    try:
        return await instance_for(doc).balance()
    except VendorError as exc:
        return {"supported": True, "ok": False, "message": str(exc)}


@router.get("/topup/vendors/{provider_id}/products")
async def vendor_products(provider_id: str, q: str | None = None, brand: str | None = None,
                          limit: int = 100):
    """Preview the supplier's price list (used to pick SKUs for a game)."""
    doc = await topup_providers.find_one({"id": provider_id}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Supplier tidak ditemukan")
    try:
        items = await instance_for(doc).list_products()
    except VendorError as exc:
        raise HTTPException(400, str(exc))
    rows = [item.__dict__ for item in items]
    if brand:
        needle = brand.strip().lower()
        rows = [r for r in rows if needle in (r["brand"] or "").lower() or needle in (r["category"] or "").lower()]
    if q:
        needle = q.strip().lower()
        rows = [r for r in rows if needle in r["sku"].lower() or needle in r["name"].lower()]
    return {"count": len(rows), "total": len(items), "products": rows[: max(1, min(limit, 500))]}


@router.post("/topup/games/{game_id}/import")
async def import_game_products(game_id: str, data: dict = Body(...)):
    """Attach supplier SKUs to a game's denominations in bulk.

    Body: ``{"provider_id": "...", "skus": {"<denomination_code>": "<sku>"}}`` —
    copying ``vendor_sku``/``vendor_price`` onto each denomination, then syncing
    the catalogue products.
    """
    game = await games.find_one({"id": game_id}, {"_id": 0})
    if not game:
        raise HTTPException(404, "Game tidak ditemukan")
    mapping = data.get("skus")
    if not isinstance(mapping, dict) or not mapping:
        raise HTTPException(400, "Pilih minimal satu SKU untuk diimpor")
    provider_id = (data.get("provider_id") or "").strip()

    denoms = list(game.get("denominations") or [])
    updated_codes: list[str] = []
    for denom in denoms:
        code = str(denom.get("code"))
        entry = mapping.get(code)
        if entry is None:
            continue
        sku = entry.get("sku") if isinstance(entry, dict) else str(entry)
        price = entry.get("price") if isinstance(entry, dict) else None
        if not (sku or "").strip():
            continue
        denom["vendor_sku"] = sku.strip()
        if price is not None and data.get("apply_price"):
            try:
                listed = int(price)
                margin = float(data.get("margin_percent") or 0)
                denom["price"] = int(round(listed * (1 + margin / 100)))
            except (TypeError, ValueError):
                pass
        updated_codes.append(code)

    if not updated_codes:
        raise HTTPException(400, "Tidak ada SKU valid yang dikirim")

    changes = {"denominations": denoms, "updated_at": now_iso()}
    if provider_id:
        changes["vendor_id"] = provider_id
    await games.update_one({"id": game_id}, {"$set": changes})
    product_count = await sync_game_products({**game, **changes})
    return {
        "ok": True,
        "updated": updated_codes,
        "products": product_count,
        "message": f"{len(updated_codes)} nominal dihubungkan ke supplier",
    }


@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(400, "Hanya file gambar (JPG, PNG, WEBP, GIF) yang diizinkan")
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(400, "Ukuran file maksimal 5MB")
    ext = os.path.splitext(file.filename or "")[1] or ".jpg"
    path = f"uploads/{uuid4().hex}{ext}"
    await files.insert_one({
        "path": path, "data": data, "content_type": file.content_type,
        "filename": file.filename, "created_at": now_iso(),
    })
    return {"url": f"/api/files/{path}"}


# --- Manual payment destinations ---
@router.get("/payments/manual-destinations")
async def list_destinations():
    rows = await manual_destinations.find({}, {"_id": 0}).sort("seq", 1).to_list(length=200)
    return rows


@router.post("/payments/manual-destinations", status_code=201)
async def create_destination(data: dict = Body(...)):
    if not data.get("name") or not data.get("type"):
        raise HTTPException(400, "Nama dan tipe diperlukan")
    last = await manual_destinations.find_one({}, sort=[("seq", -1)])
    dest = {
        "id": "mp-" + uuid4().hex[:10],
        "name": data["name"],
        "account_name": data.get("account_name") or "",
        "account_number": data.get("account_number") or "",
        "type": data["type"],
        "image": data.get("image") or "",
        "is_active": bool(data.get("is_active", True)),
        "seq": (last.get("seq", 0) + 1) if last else 0,
    }
    await manual_destinations.insert_one(dict(dest))
    return clean(dest)


@router.put("/payments/manual-destinations/{dest_id}")
async def update_destination(dest_id: str, data: dict = Body(...)):
    existing = await manual_destinations.find_one({"id": dest_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Tujuan pembayaran tidak ditemukan")
    data.pop("_id", None)
    allowed = {"name", "type", "account_name", "account_number", "image", "is_active"}
    updated = {**existing, **{k: v for k, v in data.items() if k in allowed}, "id": dest_id}
    if not updated.get("name") or not updated.get("type"):
        raise HTTPException(400, "Nama dan tipe diperlukan")
    updated["is_active"] = bool(updated.get("is_active", True))
    await manual_destinations.update_one({"id": dest_id}, {"$set": {k: v for k, v in updated.items() if k != "id"}})
    return updated


@router.delete("/payments/manual-destinations/{dest_id}")
async def delete_destination(dest_id: str):
    res = await manual_destinations.delete_one({"id": dest_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Tujuan pembayaran tidak ditemukan")
    return {"message": "Tujuan pembayaran dihapus"}


# --- PayKita API & Webhook settings ---
@router.get("/payments/paykita")
async def get_paykita():
    s = await get_paykita_settings()
    products_with_key = await products.count_documents({"paykita.api_key": {"$exists": True, "$ne": ""}})
    return {
        "enabled": s.get("enabled", False),
        "base_url": s.get("base_url", "https://pay.digikita.id"),
        "api_key_set": bool(s.get("api_key")),
        "api_key_masked": _masked(s.get("api_key", "")),
        "webhook_secret_set": bool(s.get("webhook_secret")),
        "webhook_url": f"{FRONTEND_URL}/api/webhook/paykita",
        "products_with_own_key": products_with_key,
        "last_test": s.get("last_test"),
    }


@router.post("/payments/paykita/test")
async def test_paykita(data: dict = Body(default={})):
    s = await get_paykita_settings()
    creds = {
        "api_key": (data.get("api_key") or "").strip() or s.get("api_key") or "",
        "base_url": ((data.get("base_url") or s.get("base_url") or "https://pay.digikita.id").rstrip("/")),
    }
    if not creds["api_key"]:
        raise HTTPException(400, "Masukkan API key PayKita terlebih dahulu")
    created = await paykita_call(creds, "POST", "/api/orders", {"base_amount": 1000, "reference": f"TEST-{int(time.time())}"})
    info = _extract_paykita(created or {})
    if info.get("paykita_order_id"):
        try:
            await paykita_call(creds, "POST", f"/api/orders/{info['paykita_order_id']}/cancel")
        except HTTPException:
            pass
    result = {"ok": True, "project": info.get("project"), "provider": info.get("provider"),
              "mode": info.get("mode"), "qris_ready": bool(info.get("qris_string")), "tested_at": now_iso()}
    if not data.get("api_key"):
        await settings.update_one({"id": "paykita"}, {"$set": {"last_test": result}}, upsert=True)
    return result


@router.post("/payments/paykita/test-product/{product_id}")
async def test_product_paykita(product_id: str):
    product = await products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Produk tidak ditemukan")
    creds = await paykita_creds(product)
    if not creds["api_key"]:
        raise HTTPException(400, "Belum ada API key PayKita (produk maupun global)")
    created = await paykita_call(creds, "POST", "/api/orders", {"base_amount": 1000, "reference": f"TEST-{product_id}-{int(time.time())}"})
    info = _extract_paykita(created or {})
    if info.get("paykita_order_id"):
        try:
            await paykita_call(creds, "POST", f"/api/orders/{info['paykita_order_id']}/cancel")
        except HTTPException:
            pass
    return {"ok": True, "source": creds["source"], "project": info.get("project"), "provider": info.get("provider"), "mode": info.get("mode")}


@router.post("/orders/{session_id}/sync")
async def sync_order(session_id: str):
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx or tx.get("provider") != "paykita":
        raise HTTPException(404, "Transaksi PayKita tidak ditemukan")
    info = await sync_paykita(tx)
    return {"payment_status": tx["payment_status"], "status": tx.get("status"), "paykita_status": info.get("status")}


@router.put("/payments/paykita")
async def update_paykita(data: dict = Body(...)):
    s = await get_paykita_settings()
    update = {
        "id": "paykita",
        "enabled": bool(data.get("enabled", s.get("enabled", False))),
        "base_url": (data.get("base_url") or s.get("base_url") or "https://pay.digikita.id").rstrip("/"),
        "api_key": s.get("api_key", ""),
        "webhook_secret": s.get("webhook_secret", ""),
    }
    # Only overwrite secrets if a non-empty value was explicitly provided.
    if (data.get("api_key") or "").strip():
        update["api_key"] = data["api_key"].strip()
    if "webhook_secret" in data and (data.get("webhook_secret") or "").strip() != "":
        update["webhook_secret"] = data["webhook_secret"].strip()
    await settings.update_one({"id": "paykita"}, {"$set": update}, upsert=True)
    return await get_paykita()



# --- Social media links ---
@router.get("/social-links")
async def admin_social_links():
    return await social_links.find({}, {"_id": 0}).sort("seq", 1).to_list(length=200)


@router.post("/social-links", status_code=201)
async def create_social_link(data: dict = Body(...)):
    if not (data.get("name") or "").strip() or not (data.get("url") or "").strip():
        raise HTTPException(400, "Nama dan URL diperlukan")
    last = await social_links.find_one({}, sort=[("seq", -1)])
    link = {
        "id": "sl-" + uuid4().hex[:10],
        "platform": (data.get("platform") or "website").strip(),
        "name": data["name"].strip(),
        "url": data["url"].strip(),
        "is_active": bool(data.get("is_active", True)),
        "seq": (last.get("seq", 0) + 1) if last else 0,
    }
    await social_links.insert_one(dict(link))
    return clean(link)


@router.put("/social-links/{link_id}")
async def update_social_link(link_id: str, data: dict = Body(...)):
    existing = await social_links.find_one({"id": link_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Sosial media tidak ditemukan")
    data.pop("_id", None)
    allowed = {"platform", "name", "url", "is_active"}
    updated = {**existing, **{k: v for k, v in data.items() if k in allowed}, "id": link_id}
    if not (updated.get("name") or "").strip() or not (updated.get("url") or "").strip():
        raise HTTPException(400, "Nama dan URL diperlukan")
    updated["is_active"] = bool(updated.get("is_active", True))
    await social_links.update_one({"id": link_id}, {"$set": {k: v for k, v in updated.items() if k != "id"}})
    return updated


@router.delete("/social-links/{link_id}")
async def delete_social_link(link_id: str):
    res = await social_links.delete_one({"id": link_id})
    if res.deleted_count == 0:
        raise HTTPException(404, "Sosial media tidak ditemukan")
    return {"message": "Sosial media dihapus"}


# --- Topup: games & denominations ---
GAME_FIELD_KEYS = {"key", "label", "placeholder", "type", "inputmode", "required",
                   "min_len", "max_len", "pattern", "help"}
DENOM_KEYS = {"code", "label", "amount", "price", "price_strike", "stock", "badge",
              "is_active", "seq", "featured", "sold", "rating"}


def _slugify(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")


def _clean_fields(raw) -> list[dict]:
    fields: list[dict] = []
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        field = {k: v for k, v in item.items() if k in GAME_FIELD_KEYS}
        if not (field.get("key") or "").strip():
            continue
        field["key"] = re.sub(r"[^a-z0-9_]", "", field["key"].strip().lower())
        if not field["key"]:
            continue
        field.setdefault("label", field["key"].replace("_", " ").title())
        field["required"] = bool(field.get("required", True))
        for numeric in ("min_len", "max_len"):
            if field.get(numeric) not in (None, ""):
                field[numeric] = _num(field[numeric], 0, int)
            else:
                field.pop(numeric, None)
        if not (field.get("pattern") or "").strip():
            field.pop("pattern", None)
        fields.append(field)
    return fields


def _clean_denominations(raw) -> list[dict]:
    denoms: list[dict] = []
    seen: set[str] = set()
    for index, item in enumerate(raw or []):
        if not isinstance(item, dict):
            continue
        code = str(item.get("code") or "").strip()
        if not code or code in seen:
            continue
        seen.add(code)
        denoms.append({
            "code": code,
            "label": (item.get("label") or "").strip() or code,
            "amount": _num(item.get("amount"), 0, int),
            "price": _num(item.get("price"), 0, int),
            "price_strike": _num(item.get("price_strike"), 0, int) or None,
            "stock": _num(item.get("stock"), 0, int),
            "badge": (item.get("badge") or "").strip(),
            "is_active": bool(item.get("is_active", True)),
            "featured": bool(item.get("featured", False)),
            "sold": _num(item.get("sold"), 0, int),
            "rating": _num(item.get("rating"), 4.9),
            "seq": _num(item.get("seq"), index, int),
        })
    return denoms


def _game_payload(data: dict, existing: dict | None = None) -> dict:
    base = dict(existing or {})
    name = (data.get("name") or base.get("name") or "").strip()
    if not name:
        raise HTTPException(400, "Nama game wajib diisi")
    slug = _slugify(data.get("slug") or base.get("slug") or name)
    if not slug:
        raise HTTPException(400, "Slug game tidak valid")
    fields = _clean_fields(data.get("fields", base.get("fields")))
    if not fields:
        raise HTTPException(400, "Minimal satu field tujuan (mis. User ID) wajib didefinisikan")
    denoms = _clean_denominations(data.get("denominations", base.get("denominations")))
    if not denoms:
        raise HTTPException(400, "Minimal satu nominal top up wajib diisi")
    return {
        **base,
        **{k: v for k, v in data.items() if k in ("publisher", "icon", "banner", "currency",
                                                  "notes", "delivery_info")},
        "id": base.get("id") or f"g-{slug}",
        "slug": slug,
        "name": name,
        "publisher": (data.get("publisher", base.get("publisher")) or "").strip(),
        "icon": (data.get("icon", base.get("icon")) or "").strip(),
        "banner": (data.get("banner", base.get("banner")) or "").strip(),
        "currency": (data.get("currency", base.get("currency")) or "Item").strip(),
        "notes": (data.get("notes", base.get("notes")) or "").strip(),
        "delivery_info": (data.get("delivery_info", base.get("delivery_info")) or "").strip(),
        "is_active": bool(data.get("is_active", base.get("is_active", True))),
        "featured": bool(data.get("featured", base.get("featured", False))),
        "seq": _num(data.get("seq"), base.get("seq", 0), int),
        "fields": fields,
        "denominations": denoms,
        "updated_at": now_iso(),
        "created_at": base.get("created_at") or now_iso(),
    }


@router.get("/games")
async def admin_games():
    rows = await games.find({}, {"_id": 0}).sort("seq", 1).to_list(length=200)
    for row in rows:
        codes = {str(d.get("code")) for d in row.get("denominations") or []}
        mirrored = await products.find(
            {"slug": row.get("slug"), "product_type": "topup"}, {"_id": 0, "denomination_code": 1}
        ).to_list(length=500)
        row["products_synced"] = len(codes) > 0 and codes.issubset(
            {str(p.get("denomination_code")) for p in mirrored}
        )
        row["product_count"] = len(mirrored)
    return rows


@router.post("/games", status_code=201)
async def create_game(data: dict = Body(...)):
    payload = _game_payload(data)
    if await games.find_one({"slug": payload["slug"]}, {"_id": 0}):
        raise HTTPException(400, "Game dengan slug tersebut sudah ada")
    await games.insert_one(dict(payload))
    await sync_game_products(payload)
    return clean(payload)


@router.put("/games/{game_id}")
async def update_game(game_id: str, data: dict = Body(...)):
    existing = await games.find_one({"id": game_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Game tidak ditemukan")
    data.pop("_id", None)
    payload = _game_payload({**data, "id": None}, existing)
    conflict = await games.find_one({"slug": payload["slug"], "id": {"$ne": game_id}}, {"_id": 0})
    if conflict:
        raise HTTPException(400, "Slug game sudah dipakai game lain")
    await games.update_one({"id": game_id}, {"$set": {k: v for k, v in payload.items() if k != "id"}})
    await sync_game_products(payload)
    return clean(payload)


@router.delete("/games/{game_id}")
async def delete_game(game_id: str):
    existing = await games.find_one({"id": game_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Game tidak ditemukan")
    await games.delete_one({"id": game_id})
    removed = await products.delete_many({"slug": existing.get("slug"), "product_type": "topup"})
    return {"ok": True, "products_removed": removed.deleted_count}


@router.post("/games/sync")
async def sync_games():
    count = await sync_all_games()
    return {"ok": True, "products": count}


@router.get("/games/{game_id}/preview")
async def preview_game(game_id: str):
    existing = await games.find_one({"id": game_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Game tidak ditemukan")
    return public_game(existing)


# --- Topup orders ---
def _topup_query() -> dict:
    return {"product_type": "topup"}


@router.get("/topup/orders")
async def list_topup_orders(status: str | None = None, game: str | None = None):
    query = _topup_query()
    if status:
        query["payment_status"] = status
    if game:
        query["game_slug"] = game
    orders = await transactions.find(query, {"_id": 0, "payment_proof": 0}).sort("created_at", -1).to_list(length=1000)
    for order in orders:
        order["has_proof"] = bool(order.get("has_proof"))
    return orders


@router.get("/topup/orders/{session_id}")
async def get_topup_order(session_id: str):
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx or tx.get("product_type") != "topup":
        raise HTTPException(404, "Pesanan top up tidak ditemukan")
    return tx


@router.post("/topup/orders/{session_id}/complete")
async def complete_topup_order(session_id: str, data: dict = Body(default={})):
    """Mark a paid topup order as delivered (optionally auto-dispatch to the provider)."""
    tx = await transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not tx or tx.get("product_type") != "topup":
        raise HTTPException(404, "Pesanan top up tidak ditemukan")
    if tx.get("payment_status") != "paid":
        raise HTTPException(400, "Pesanan belum lunas. Setujui pembayaran terlebih dahulu.")

    note = (data.get("note") or "").strip()
    dispatched = False
    provider_message = ""
    if data.get("dispatch") and not tx.get("provider_order_id"):
        game = await games.find_one({"slug": tx.get("game_slug")}, {"_id": 0}) or {}
        result = await fulfil(tx, game, tx.get("destination") or {})
        dispatched = result.dispatched
        provider_message = result.message
        if result.dispatched:
            tx["provider_order_id"] = (result.raw or {}).get("id") or session_id

    changes = {
        "status": "delivered",
        "delivered_at": now_iso(),
        "updated_at": now_iso(),
    }
    if note:
        changes["admin_note"] = note
    if dispatched:
        changes["provider_status"] = provider_message
    await transactions.update_one({"session_id": session_id}, {"$set": changes})
    return {**tx, **changes, "dispatched": dispatched}

