import os
import base64
import hashlib
import hmac
import json
import logging
import random
import re
import string
import time

import httpx
from fastapi import APIRouter, HTTPException, Request, Body, UploadFile, File

from db import products, transactions, manual_destinations, clean, now_iso, get_paykita_settings, games
from topup_catalog import (
    TOPUP_CATEGORY,
    PRODUCT_TYPE,
    find_denomination,
    render_delivery_info,
    validate_destination,
)

logger = logging.getLogger("payments")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
router = APIRouter(prefix="/payments")

FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:3000")

PAID_STATES = {"paid", "success", "settlement", "completed", "capture", "done"}
EXPIRED_STATES = {"expire", "expired"}
FAILED_STATES = {"cancel", "cancelled", "canceled", "deny", "failed", "void", "rejected"}
SIGNATURE_HEADERS = ("x-signature", "x-paykita-signature", "x-callback-signature", "x-webhook-signature", "signature", "x-hub-signature-256")
SYNC_INTERVAL = 8


def _order_id(prefix: str) -> str:
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"{prefix}-{str(int(time.time() * 1000))[-6:]}-{suffix}"


async def _get_tx(session_id: str):
    return await transactions.find_one({"session_id": session_id}, {"_id": 0})


async def _set_tx(session_id: str, **changes):
    await transactions.update_one({"session_id": session_id}, {"$set": changes})


async def _deduct_stock(tx: dict):
    if tx.get("stock_deducted"):
        return
    await products.update_one({"id": tx["product_id"], "stock": {"$gt": 0}}, {"$inc": {"stock": -1}})
    await products.update_one({"id": tx["product_id"]}, {"$inc": {"sold": 1}})
    await _set_tx(tx["session_id"], stock_deducted=True)
    tx["stock_deducted"] = True


async def _product_for_checkout(product_id: str) -> dict:
    product = await products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Produk tidak ditemukan")
    if (product.get("stock") or 0) < 1:
        raise HTTPException(400, "Stok produk habis")
    return product


def _buyer(body: dict) -> dict:
    email = (body.get("buyer_email") or "").strip().lower()
    wa = re.sub(r"[^\d]", "", body.get("buyer_whatsapp") or "")
    if wa.startswith("0"):
        wa = "62" + wa[1:]
    if not email and not wa:
        raise HTTPException(400, "Isi email atau nomor WhatsApp untuk pengiriman pesanan")
    if email and not EMAIL_RE.match(email):
        raise HTTPException(400, "Format email tidak valid")
    if wa and not (9 <= len(wa) <= 15):
        raise HTTPException(400, "Nomor WhatsApp tidak valid")
    return {"buyer_email": email or None, "buyer_whatsapp": wa or None}


# ---------------- PayKita credentials (per product override -> global) ----------------
async def paykita_creds(product: dict | None) -> dict:
    s = await get_paykita_settings()
    pp = (product or {}).get("paykita") or {}
    creds = {"enabled": bool(s.get("enabled")), "base_url": s["base_url"], "source": "global",
             "api_key": s.get("api_key") or "", "webhook_secret": s.get("webhook_secret") or ""}
    if pp.get("api_key"):
        creds.update(source="product", api_key=pp["api_key"], webhook_secret=pp.get("webhook_secret") or creds["webhook_secret"])
    return creds


async def paykita_call(creds: dict, method: str, path: str, payload: dict | None = None) -> dict:
    try:
        async with httpx.AsyncClient(timeout=15.0) as http:
            res = await http.request(
                method, f"{creds['base_url']}{path}", json=payload,
                headers={"x-api-key": creds["api_key"], "content-type": "application/json", "Accept": "application/json"},
            )
        res.raise_for_status()
        return res.json()
    except httpx.HTTPStatusError as exc:
        logger.error("PayKita %s %s error: %s %s", method, path, exc.response.status_code, exc.response.text[:300])
        if exc.response.status_code in (401, 403):
            raise HTTPException(502, "API key PayKita tidak valid atau langganan REST API belum aktif.")
        if exc.response.status_code == 404:
            raise HTTPException(502, "Order tidak ditemukan di PayKita.")
        raise HTTPException(502, "PayKita menolak permintaan. Periksa API key/langganan.")
    except (httpx.HTTPError, ValueError) as exc:
        logger.error("PayKita connection error: %s", exc)
        raise HTTPException(502, "Tidak dapat terhubung ke PayKita. Coba lagi nanti.")


def _pick(d: dict, *keys):
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            return v
    return None


def _extract_paykita(resp: dict) -> dict:
    d = resp.get("data") if isinstance(resp.get("data"), dict) else resp
    return {
        "paykita_order_id": _pick(d, "id", "order_id", "orderId", "trx_id", "transaction_id"),
        "qris_string": _pick(d, "qris", "qris_string", "qr_string", "qr_content", "qr_raw", "qris_content"),
        "qris_image": _pick(d, "qris_image", "qr_image", "qris_url", "qr_url", "qris_image_url", "qr_image_url", "qr_image_base64"),
        "final_amount": _pick(d, "pay_amount", "final_amount", "net_amount", "total", "amount", "gross_amount", "nominal"),
        "expired_at": _pick(d, "expires_at", "expired_at", "expiry", "expire_at", "expiry_time"),
        "pay_url": _pick(d, "checkout_url", "payment_url", "pay_url", "url"),
        "status": _pick(d, "status", "transaction_status", "payment_status", "state"),
        "project": (d.get("project") or {}).get("name") if isinstance(d.get("project"), dict) else None,
        "provider": _pick(d, "payment_provider", "provider"),
        "mode": d.get("mode"),
    }


@router.get("/methods")
async def payment_methods(product_id: str | None = None):
    methods = [{"id": "manual", "label": "Transfer Manual"}]
    product = await products.find_one({"id": product_id}, {"_id": 0}) if product_id else None
    creds = await paykita_creds(product)
    if creds["enabled"] and creds["api_key"]:
        methods.append({"id": "paykita", "label": "QRIS Otomatis (PayKita)"})
    return methods


@router.get("/manual-destinations")
async def manual_destinations_list():
    rows = await manual_destinations.find({"is_active": True}, {"_id": 0}).sort("seq", 1).to_list(length=200)
    return rows


# ---------------- Topup (game ID + denomination) ----------------
async def _topup_context(body: dict) -> tuple[dict, dict, dict, dict, dict]:
    """Resolve (game, denomination, product, destination, buyer) for a topup checkout."""
    slug = str(body.get("game") or body.get("slug") or "").strip()
    if not slug:
        raise HTTPException(400, "Game wajib dipilih untuk top up")
    game = await games.find_one({"slug": slug}, {"_id": 0})
    if not game:
        raise HTTPException(404, "Game tidak ditemukan")
    if not game.get("is_active", True):
        raise HTTPException(400, "Top up untuk game ini sedang tidak tersedia")

    code = str(body.get("denomination_code") or body.get("denomination") or "").strip()
    denom = find_denomination(game, code)
    if not denom or not denom.get("is_active", True):
        raise HTTPException(404, "Nominal top up tidak tersedia")

    product_id = str(body.get("product_id") or "").strip()
    product = await products.find_one({"id": product_id}, {"_id": 0}) if product_id else None
    if not product:
        raise HTTPException(404, "Nominal top up tidak ditemukan di katalog")
    if product.get("product_type") != PRODUCT_TYPE:
        raise HTTPException(400, "Produk bukan nominal top up")

    values = body.get("destination")
    if not isinstance(values, dict):
        values = {f.get("key"): body.get(f.get("key")) for f in game.get("fields") or []}
    ok, destination, error = validate_destination(game, values)
    if not ok:
        raise HTTPException(400, error)
    if (product.get("stock") or 0) < 1:
        raise HTTPException(400, "Nominal ini sedang habis, pilih nominal lain")

    return game, denom, product, destination, _buyer(body)


async def _record_topup(game: dict, denom: dict, product: dict, destination: dict,
                        buyer: dict, order_id: str, user, **extra) -> dict:
    label = denom.get("label") or denom.get("code")
    doc = {
        **buyer,
        "session_id": order_id,
        "product_id": product["id"],
        "product_title": product.get("title") or f"{game.get('name')} — {label}",
        "product_type": PRODUCT_TYPE,
        "category": TOPUP_CATEGORY,
        "game_id": game.get("id"),
        "game_slug": game.get("slug"),
        "game_name": game.get("name"),
        "denomination_code": str(denom.get("code")),
        "denomination_label": label,
        "destination": destination,
        "delivery_info": render_delivery_info(product, game, destination),
        "user_id": user["id"] if user else None,
        "amount": int(round(float(product.get("price") or 0))),
        "price_strike": product.get("price_strike"),
        "currency": "idr",
        "status": "pending",
        "payment_status": "pending",
        "has_proof": False,
        "stock_deducted": False,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        **extra,
    }
    await transactions.insert_one(dict(doc))
    return doc


@router.post("/topup/checkout")
async def topup_checkout(request: Request, body: dict = Body(...)):
    """Create a topup order and return a checkout URL.

    ``method`` accepts ``manual`` (default; requires ``destination_id``) or
    ``paykita`` (QRIS). Both reuse the exact stock/approval flow of the regular
    product checkout.
    """
    game, denom, product, destination, buyer = await _topup_context(body)
    from auth import get_user_optional
    user = await get_user_optional(request)
    method = (body.get("method") or "manual").strip().lower()
    origin = body.get("origin_url") or request.headers.get("origin") or FRONTEND_URL
    price = int(round(float(product.get("price") or 0)))

    if method == "paykita":
        creds = await paykita_creds(product)
        if not creds["enabled"] or not creds["api_key"]:
            raise HTTPException(503, "Pembayaran QRIS belum tersedia. Gunakan Transfer Manual.")
        order_id = _order_id("PK")
        success_url = f"{origin}/payment/success?session_id={order_id}"
        webhook_url = f"{FRONTEND_URL}/api/webhook/paykita" + (
            f"/{product['id']}" if creds["source"] == "product" else ""
        )
        resp_json = await paykita_call(creds, "POST", "/api/orders", {
            "base_amount": price, "reference": order_id,
            "webhook_url": webhook_url, "redirect_url": success_url,
        })
        info = _extract_paykita(resp_json or {})
        amount = int(round(float(info["final_amount"]))) if info.get("final_amount") else price
        await _record_topup(
            game, denom, product, destination, buyer, order_id, user,
            provider="paykita",
            paykita_source=creds["source"],
            amount=amount,
            base_amount=price,
            paykita_order_id=info.get("paykita_order_id"),
            qris_string=info.get("qris_string"),
            qris_image=info.get("qris_image"),
            pay_url=info.get("pay_url"),
            expired_at=info.get("expired_at"),
            paykita_raw=resp_json,
            last_sync_at=time.time(),
        )
        return {"order_id": order_id, "session_id": order_id, "checkout_url": success_url}

    dest = await manual_destinations.find_one(
        {"id": body.get("destination_id") or "", "is_active": True}, {"_id": 0}
    )
    if not dest:
        raise HTTPException(404, "Metode pembayaran manual tidak ditemukan / tidak aktif")
    order_id = _order_id("NXG-T")
    await _record_topup(
        game, denom, product, destination, buyer, order_id, user,
        provider="manual",
        destination_id=dest["id"],
        destination_name=dest["name"],
        payment_proof=None,
    )
    return {"order_id": order_id, "session_id": order_id,
            "checkout_url": f"{origin}/payment/success?session_id={order_id}"}


# ---------------- Manual transfer ----------------
@router.post("/manual/checkout")
async def manual_checkout(request: Request, body: dict = Body(...)):
    product = await _product_for_checkout(body.get("product_id", ""))
    buyer = _buyer(body)
    dest = await manual_destinations.find_one(
        {"id": body.get("destination_id") or "", "is_active": True}, {"_id": 0}
    )
    if not dest:
        raise HTTPException(404, "Metode pembayaran manual tidak ditemukan / tidak aktif")
    from auth import get_user_optional
    user = await get_user_optional(request)
    order_id = _order_id("NXG-M")
    await transactions.insert_one({
        **buyer,
        "session_id": order_id,
        "provider": "manual",
        "destination_id": dest["id"],
        "destination_name": dest["name"],
        "product_id": product["id"],
        "product_title": product.get("title"),
        "delivery_info": product.get("delivery_info") or "Data login akan dikirimkan via WhatsApp setelah verifikasi",
        "user_id": user["id"] if user else None,
        "amount": int(round(float(product.get("price") or 0))),
        "currency": "idr",
        "status": "pending",
        "payment_status": "pending",
        "payment_proof": None,
        "has_proof": False,
        "stock_deducted": False,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    })
    origin = body.get("origin_url") or request.headers.get("origin") or FRONTEND_URL
    return {"order_id": order_id, "session_id": order_id,
            "checkout_url": f"{origin}/payment/success?session_id={order_id}"}


@router.post("/manual/upload-proof/{session_id}")
async def upload_proof(session_id: str, proof: UploadFile = File(...)):
    tx = await _get_tx(session_id)
    if not tx or tx.get("provider") != "manual":
        raise HTTPException(404, "Transaksi manual tidak valid atau tidak ditemukan")
    if tx.get("payment_status") == "paid":
        raise HTTPException(400, "Pesanan ini sudah lunas")
    if not (proof.content_type or "").startswith("image/"):
        raise HTTPException(400, "Bukti transfer harus berupa gambar (JPG/PNG/WEBP)")
    data = await proof.read()
    if not data:
        raise HTTPException(400, "File bukti transfer kosong")
    if len(data) > 5 * 1024 * 1024:
        raise HTTPException(400, "Ukuran file maksimal 5MB")
    changes = {
        "payment_proof": f"data:{proof.content_type};base64,{base64.b64encode(data).decode()}",
        "has_proof": True,
        "status": "waiting_approval",
        "updated_at": now_iso(),
    }
    await _set_tx(session_id, **changes)
    return {**clean(tx), **changes}


# ---------------- PayKita (QRIS automatic) ----------------
@router.post("/paykita/checkout")
async def paykita_checkout(request: Request, body: dict = Body(...)):
    product = await _product_for_checkout(body.get("product_id", ""))
    creds = await paykita_creds(product)
    if not creds["enabled"] or not creds["api_key"]:
        raise HTTPException(503, "Pembayaran PayKita belum dikonfigurasi. Gunakan Transfer Manual.")
    buyer = _buyer(body)
    from auth import get_user_optional
    user = await get_user_optional(request)
    order_id = _order_id("PK")
    price = int(round(float(product.get("price") or 0)))
    origin = body.get("origin_url") or request.headers.get("origin") or FRONTEND_URL
    success_url = f"{origin}/payment/success?session_id={order_id}"
    webhook_url = f"{FRONTEND_URL}/api/webhook/paykita" + (f"/{product['id']}" if creds["source"] == "product" else "")

    resp_json = await paykita_call(creds, "POST", "/api/orders", {
        "base_amount": price, "reference": order_id,
        "webhook_url": webhook_url, "redirect_url": success_url,
    })
    info = _extract_paykita(resp_json or {})
    amount = int(round(float(info["final_amount"]))) if info.get("final_amount") else price

    await transactions.insert_one({
        **buyer,
        "session_id": order_id,
        "provider": "paykita",
        "paykita_source": creds["source"],
        "product_id": product["id"],
        "product_title": product.get("title"),
        "delivery_info": product.get("delivery_info") or "Data login akan dikirimkan via WhatsApp setelah verifikasi",
        "user_id": user["id"] if user else None,
        "amount": amount,
        "base_amount": price,
        "currency": "idr",
        "status": "pending",
        "payment_status": "pending",
        "paykita_order_id": info.get("paykita_order_id"),
        "qris_string": info.get("qris_string"),
        "qris_image": info.get("qris_image"),
        "pay_url": info.get("pay_url"),
        "expired_at": info.get("expired_at"),
        "paykita_raw": resp_json,
        "last_sync_at": time.time(),
        "has_proof": False,
        "stock_deducted": False,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    })
    return {"order_id": order_id, "session_id": order_id, "checkout_url": success_url}


async def _apply_paykita_status(tx: dict, status_val, payment_type=None):
    s = str(status_val or "").lower()
    changes = {}
    if s in PAID_STATES:
        changes = {"payment_status": "paid", "status": "completed"}
    elif s in EXPIRED_STATES:
        changes = {"payment_status": "failed", "status": "expired"}
    elif s in FAILED_STATES:
        changes = {"payment_status": "failed", "status": "failed"}
    if not changes:
        return
    changes["payment_type"] = payment_type or tx.get("payment_type") or "qris"
    changes["updated_at"] = now_iso()
    await _set_tx(tx["session_id"], **changes)
    tx.update(changes)
    if tx.get("payment_status") == "paid":
        await _deduct_stock(tx)


async def sync_paykita(tx: dict) -> dict:
    """Authoritative status check against PayKita API. Returns extracted info."""
    if not tx.get("paykita_order_id"):
        raise HTTPException(502, "Order PayKita tidak memiliki ID.")
    product = await products.find_one({"id": tx.get("product_id")}, {"_id": 0})
    creds = await paykita_creds(product)
    if not creds["api_key"]:
        raise HTTPException(503, "API key PayKita tidak tersedia.")
    resp = await paykita_call(creds, "GET", f"/api/orders/{tx['paykita_order_id']}")
    info = _extract_paykita(resp or {})
    await _set_tx(tx["session_id"], last_sync_at=time.time())
    await _apply_paykita_status(tx, info.get("status"))
    return info


# ---------------- Status polling ----------------
@router.get("/status/{session_id}")
async def payment_status(session_id: str):
    tx = await _get_tx(session_id)
    if not tx:
        raise HTTPException(404, "Transaksi tidak ditemukan")

    if tx.get("provider") == "manual":
        dest = None
        if tx.get("destination_id"):
            dest = await manual_destinations.find_one({"id": tx["destination_id"]}, {"_id": 0})
        base = {k: v for k, v in tx.items() if k != "payment_proof"}
        return {**base, "manual_destination": dest}

    if tx.get("provider") == "paykita" and tx.get("payment_status") == "pending" \
            and time.time() - float(tx.get("last_sync_at") or 0) > SYNC_INTERVAL:
        try:
            await sync_paykita(tx)
        except HTTPException as exc:
            logger.warning("PayKita sync skipped for %s: %s", session_id, exc.detail)

    paid = tx.get("payment_status") == "paid"
    game = None
    if tx.get("product_type") == PRODUCT_TYPE and tx.get("game_slug"):
        game = await games.find_one({"slug": tx["game_slug"]}, {"_id": 0})
        if game:
            game = {"id": game.get("id"), "slug": game.get("slug"), "name": game.get("name"),
                    "fields": game.get("fields") or []}
    return {
        "session_id": tx["session_id"],
        "provider": tx.get("provider"),
        "status": tx.get("status") or "pending",
        "payment_status": tx.get("payment_status") or "pending",
        "payment_type": tx.get("payment_type") or tx.get("provider"),
        "amount": tx.get("amount"),
        "qris_string": tx.get("qris_string") if not paid else None,
        "qris_image": tx.get("qris_image") if not paid else None,
        "pay_url": tx.get("pay_url") if not paid else None,
        "expired_at": tx.get("expired_at"),
        "delivery_info": (tx.get("delivery_info") or "") if paid else "",
        "product_type": tx.get("product_type") or "product",
        "product_title": tx.get("product_title"),
        "game": game,
        "destination": tx.get("destination") if tx.get("product_type") == PRODUCT_TYPE else None,
        "denomination_code": tx.get("denomination_code"),
        "denomination_label": tx.get("denomination_label"),
        "admin_note": tx.get("admin_note") if paid else None,
    }


@router.post("/paykita/sync/{session_id}")
async def paykita_force_sync(session_id: str):
    tx = await _get_tx(session_id)
    if not tx or tx.get("provider") != "paykita":
        raise HTTPException(404, "Transaksi PayKita tidak ditemukan")
    if tx.get("payment_status") != "pending":
        return {"payment_status": tx["payment_status"], "status": tx.get("status")}
    await sync_paykita(tx)
    return {"payment_status": tx["payment_status"], "status": tx.get("status")}


# ---------------- Webhook ----------------
def _signature_ok(secret: str, raw: bytes, request: Request) -> bool:
    if not secret:
        return False
    provided = next((request.headers.get(h).strip() for h in SIGNATURE_HEADERS if request.headers.get(h)), "")
    if not provided:
        return False
    provided = provided.split("=", 1)[-1] if provided.lower().startswith(("sha256=", "v1=")) else provided
    digest = hmac.new(secret.encode(), raw, hashlib.sha256)
    hex_ok = hmac.compare_digest(digest.hexdigest().lower(), provided.lower())
    b64_ok = hmac.compare_digest(base64.b64encode(digest.digest()).decode(), provided)
    return hex_ok or b64_ok


async def handle_paykita_webhook(request: Request, product_id: str | None = None):
    raw = await request.body()
    try:
        n = json.loads(raw.decode() or "{}")
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(400, "Invalid payload")
    if not isinstance(n, dict):
        raise HTTPException(400, "Invalid payload")

    body = n.get("data") if isinstance(n.get("data"), dict) else n
    reference = _pick(body, "reference", "ref", "merchant_ref", "external_id")
    order_id = _pick(body, "id", "order_id", "orderId", "trx_id", "transaction_id")
    status_val = _pick(body, "status", "transaction_status", "payment_status", "state")

    tx = None
    if reference:
        tx = await _get_tx(str(reference))
    if not tx and order_id:
        tx = await transactions.find_one({"paykita_order_id": str(order_id)}, {"_id": 0})
    if not tx or tx.get("provider") != "paykita":
        logger.warning("PayKita webhook: transaction not found (ref=%s id=%s)", reference, order_id)
        return {"ok": True, "matched": False}
    if product_id and tx.get("product_id") != product_id:
        raise HTTPException(404, "Webhook produk tidak cocok")

    product = await products.find_one({"id": tx.get("product_id")}, {"_id": 0})
    creds = await paykita_creds(product)
    await _set_tx(tx["session_id"], webhook_received_at=now_iso(), webhook_payload=n)

    if _signature_ok(creds["webhook_secret"], raw, request):
        await _apply_paykita_status(tx, status_val)
        return {"ok": True, "matched": True, "verified_by": "signature", "payment_status": tx["payment_status"]}

    # Unsigned / unknown signature: never trust the payload — confirm with PayKita API.
    if tx.get("payment_status") == "pending":
        try:
            await sync_paykita(tx)
        except HTTPException as exc:
            logger.warning("PayKita webhook could not be verified via API: %s", exc.detail)
            raise HTTPException(503, "Verifikasi ke PayKita gagal, coba lagi")
    return {"ok": True, "matched": True, "verified_by": "api", "payment_status": tx["payment_status"]}


@router.post("/paykita/notification")
async def paykita_notification(request: Request):
    return await handle_paykita_webhook(request)
