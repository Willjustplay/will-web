"""Backend-agnostic document store.

The application was originally written against MongoDB (motor). To support
MariaDB without rewriting every route, collections keep a Mongo-like
asynchronous API while only a fixed, inventoried subset of features is
implemented:

    queries   {"field": value}, {"field": {"$regex"|"$gt"|"$gte"|"$lt"|"$lte"|
              "$ne"|"$in"|"$exists": ...}}, {"a.b": value}, {"$or": [...]}
    updates   {"$set": {...}}, {"$inc": {...}}
    options   upsert, return_document, sort, projection, limit

Every collection gets its own table with a business-key primary key, a set of
*promoted* columns (the fields that must be indexed, sorted or filtered) and a
JSON ``doc`` column holding the complete document, so data round-trips
unchanged. Only promoted columns are ever read for filtering/sorting; the JSON
payload stays the source of truth for everything else.

The same strategy runs on SQLite (zero-setup local runs and tests) and on
MariaDB (the production default).
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Mapping, Sequence

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Index,
    Integer,
    LargeBinary,
    MetaData,
    String,
    Table,
    and_,
    delete,
    func,
    insert as sa_insert,
    or_,
    select,
    update as sa_update,
)
from sqlalchemy.ext.asyncio import AsyncEngine

MAX_BLOB = (2**24) - 1  # MEDIUMBLOB on MySQL/MariaDB

# Only these promoted columns are coerced back to ints when read (booleans are
# stored as 0/1 to stay portable across MariaDB and SQLite).
NUMERIC_FIELDS = frozenset(
    {"price", "stock", "sold", "seq", "count", "is_active", "is_verified",
     "enabled", "featured", "verified"}
)


class DuplicateKeyError(Exception):
    """Raised when a write violates a unique constraint."""


class DeleteResult:
    def __init__(self, count: int) -> None:
        self.deleted_count = count
        self.modified_count = count


class UpdateResult:
    def __init__(self, matched: int, modified: int) -> None:
        self.matched_count = matched
        self.modified_count = modified
        self.upserted_id = None


class Query:
    """Lazily-evaluated query mirroring motor's return shape."""

    def __init__(
        self,
        collection: "Collection",
        filter_: Mapping[str, Any] | None = None,
        projection: Mapping[str, Any] | None = None,
        sort: Sequence[tuple[str, int]] | None = None,
    ) -> None:
        self._collection = collection
        self._filter = dict(filter_ or {})
        self._projection = dict(projection or {})
        self._sort = list(sort or [])
        self._limit: int | None = None

    def sort(self, key: str | Sequence[tuple[str, int]], direction: int | None = None) -> "Query":
        if isinstance(key, str):
            self._sort = [(key, direction if direction is not None else 1)]
        else:
            self._sort = list(key)
        return self

    def limit(self, n: int) -> "Query":
        self._limit = n
        return self

    async def to_list(self, length: int | None = None) -> list[dict]:
        return await self._collection._store.fetch(
            self._collection.name,
            self._filter,
            self._projection,
            self._sort,
            length or self._limit,
        )


class Collection:
    """Mongo-like facade over one SQL table."""

    def __init__(self, store: "SQLDocumentStore", name: str) -> None:
        self._store = store
        self.name = name

    # --- read ---
    def find(
        self, filter_: Mapping[str, Any] | None = None, projection: Mapping[str, Any] | None = None
    ) -> Query:
        return Query(self, filter_, projection)

    async def find_one(
        self,
        filter_: Mapping[str, Any] | None = None,
        projection: Mapping[str, Any] | None = None,
        sort: Sequence[tuple[str, int]] | None = None,
    ) -> dict | None:
        return await self._store.find_one(self.name, filter_ or {}, projection or {}, sort)

    async def count_documents(self, filter_: Mapping[str, Any] | None = None) -> int:
        return await self._store.count(self.name, filter_ or {})

    async def distinct(self, field: str, filter_: Mapping[str, Any] | None = None) -> list:
        return await self._store.distinct(self.name, field, filter_ or {})

    # --- write ---
    async def insert_one(self, doc: Mapping[str, Any]) -> Any:
        await self._store.insert(self.name, [dict(doc)])
        return doc.get("_id")

    async def insert_many(self, docs: Sequence[Mapping[str, Any]]) -> list:
        return await self._store.insert(self.name, [dict(d) for d in docs])

    async def update_one(
        self,
        filter_: Mapping[str, Any],
        change: Mapping[str, Any],
        upsert: bool = False,
        return_document: bool = False,
    ) -> dict | None:
        return await self._store.update(self.name, filter_, change, upsert, return_document)

    async def find_one_and_update(
        self,
        filter_: Mapping[str, Any],
        change: Mapping[str, Any],
        upsert: bool = False,
        return_document: bool = False,
    ) -> dict | None:
        return await self._store.update(self.name, filter_, change, upsert, return_document)

    async def update_many(
        self, filter_: Mapping[str, Any], change: Mapping[str, Any]
    ) -> UpdateResult:
        return await self._store.update_many(self.name, filter_, change)

    async def delete_one(self, filter_: Mapping[str, Any]) -> DeleteResult:
        return DeleteResult(await self._store.delete(self.name, filter_))

    async def delete_many(self, filter_: Mapping[str, Any] | None = None) -> DeleteResult:
        return DeleteResult(await self._store.delete(self.name, filter_ or {}))

    async def create_index(self, *_args: Any, **_kwargs: Any) -> None:
        """No-op.

        Indexes are declared in the table specs and built by ``create_all``. A
        unique index declared here (e.g. ``testimonials.order_id``) is unique for
        every non-NULL value, which is exactly the "one review per order"
        guarantee we want: admin-authored rows leave the column NULL.
        """


class SQLDocumentStore:
    """Single strategy for every SQL backend (MariaDB and SQLite)."""

    SPECS: dict[str, dict[str, Any]] = {
        "users": {
            "key": "id",
            "columns": {
                "email": String(191),
                "role": String(32),
                "name": String(191),
                "is_verified": Integer,
            },
            "indexes": [("email", True)],
        },
        "products": {
            "key": "id",
            "columns": {
                "game": String(191),
                "category": String(191),
                "title": String(255),
                "product_type": String(32),
                "denomination_code": String(64),
                "slug": String(191),
                "price": Integer,
                "stock": Integer,
                "sold": Integer,
                "featured": Integer,
                "seq": Integer,
            },
            "indexes": [("slug", False), ("product_type", False), ("denomination_code", False)],
        },
        "games": {
            "key": "id",
            "columns": {
                "slug": String(191),
                "name": String(191),
                "publisher": String(191),
                "is_active": Integer,
                "seq": Integer,
            },
            "indexes": [("slug", True)],
        },
        "testimonials": {
            "key": "id",
            "columns": {
                "name": String(191),
                "rating": Integer,
                "seq": Integer,
                "order_id": String(64),
                "product_id": String(64),
                "user_id": String(64),
                "source": String(16),
                "verified": Integer,
                "game": String(191),
                "created_at": String(64),
            },
            "indexes": [("order_id", True), ("product_id", False), ("source", False)],
        },
        "transactions": {
            "key": "session_id",
            "columns": {
                "user_id": String(64),
                "product_id": String(64),
                "provider": String(32),
                "status": String(32),
                "payment_status": String(32),
                "paykita_order_id": String(191),
                "product_type": String(32),
                "game_id": String(64),
                "created_at": String(64),
            },
            "indexes": [
                ("user_id", False),
                ("paykita_order_id", False),
                ("payment_status", False),
                ("created_at", False),
                ("game_id", False),
            ],
        },
        "manual_destinations": {
            "key": "id",
            "columns": {
                "type": String(32),
                "name": String(191),
                "account_name": String(191),
                "account_number": String(64),
                "is_active": Integer,
                "seq": Integer,
            },
            "indexes": [],
        },
        "social_links": {
            "key": "id",
            "columns": {
                "platform": String(64),
                "name": String(191),
                "url": String(512),
                "is_active": Integer,
                "seq": Integer,
            },
            "indexes": [],
        },
        "settings": {"key": "id", "columns": {"enabled": Integer}, "indexes": []},
        "topup_providers": {
            "key": "id",
            "columns": {
                "kind": String(32),
                "name": String(191),
                "is_active": Integer,
                "auto_dispatch": Integer,
                "seq": Integer,
            },
            "indexes": [("kind", False)],
        },
        "verification_tokens": {
            "key": "token",
            "columns": {"email": String(191), "expires_at": DateTime},
            "indexes": [("expires_at", False)],
        },
        "reset_tokens": {
            "key": "token",
            "columns": {"email": String(191), "expires_at": DateTime},
            "indexes": [("expires_at", False)],
        },
        "login_attempts": {
            "key": "identifier",
            "columns": {"count": Integer, "locked_until": DateTime},
            "indexes": [],
        },
        "files": {
            "key": "path",
            "columns": {
                "content_type": String(64),
                "filename": String(255),
                "created_at": String(64),
                "data": LargeBinary(length=MAX_BLOB),
            },
            "indexes": [],
        },
    }

    BLOB_FIELDS = frozenset({"data"})

    def __init__(self, engine: AsyncEngine) -> None:
        self.engine = engine
        self.is_mysql = engine.dialect.name in ("mysql", "mariadb")
        metadata = MetaData()
        self.tables: dict[str, Table] = {}
        for name, spec in self.SPECS.items():
            columns = [Column(spec["key"], String(191), primary_key=True)]
            for col_name, col_type in spec["columns"].items():
                if col_name == spec["key"]:
                    continue
                columns.append(Column(col_name, col_type, nullable=True))
            columns.append(Column("doc", JSON, nullable=False))
            table = Table(name, metadata, *columns)
            for field, unique in spec["indexes"]:
                if field in table.c:
                    Index(f"ix_{name}_{field}", table.c[field], unique=unique)
            self.tables[name] = table
        self.metadata = metadata
        self.collections = {name: Collection(self, name) for name in self.SPECS}

    async def create_all(self) -> None:
        async with self.engine.begin() as conn:
            await conn.run_sync(self.metadata.create_all)
        # Databases created by an earlier revision miss newly promoted columns;
        # adding them keeps upgrades non-destructive.
        await self.ensure_columns()

    async def ensure_columns(self) -> list[str]:
        """ALTER TABLE ADD COLUMN for promoted columns introduced after creation."""
        from sqlalchemy import inspect as sa_inspect

        added: list[str] = []
        for name, table in self.tables.items():
            async with self.engine.begin() as conn:
                existing = await conn.run_sync(
                    lambda sync_conn, t=table: {c["name"] for c in sa_inspect(sync_conn).get_columns(t.name)}
                    if sa_inspect(sync_conn).has_table(t.name) else None
                )
                if existing is None:
                    continue
                for column in table.columns:
                    if column.name in existing or column.primary_key:
                        continue
                    col_type = column.type.compile(dialect=self.engine.dialect)
                    nullable = "" if column.nullable else " NOT NULL"
                    default = " DEFAULT ''" if (not column.nullable and "TEXT" not in col_type.upper()) else ""
                    await conn.exec_driver_sql(
                        f'ALTER TABLE {table.name} ADD COLUMN "{column.name}" {col_type}{nullable}{default}'
                    )
                    added.append(f"{name}.{column.name}")

                have_indexes = await conn.run_sync(
                    lambda sync_conn, t=table: {i["name"] for i in sa_inspect(sync_conn).get_indexes(t.name)}
                )
                for index in table.indexes:
                    if index.name in have_indexes:
                        continue
                    unique = "UNIQUE " if index.unique else ""
                    cols = ", ".join(f'"{c.name}"' for c in index.columns)
                    await conn.exec_driver_sql(
                        f"CREATE {unique}INDEX {index.name} ON {table.name} ({cols})"
                    )
                    added.append(f"index {index.name}")
        return added

    # ------------------------------------------------------------ conversion
    def table_for(self, collection: str) -> Table:
        try:
            return self.tables[collection]
        except KeyError as exc:
            raise KeyError(f"Unknown collection: {collection}") from exc

    def _key(self, collection: str) -> str:
        return self.SPECS[collection]["key"]

    def row_to_doc(self, row: Mapping[str, Any], collection: str) -> dict:
        key = self._key(collection)
        doc = dict(row.get("doc") or {})
        for name in self.SPECS[collection]["columns"]:
            value = row.get(name)
            if name in self.BLOB_FIELDS:
                if value is not None:
                    doc[name] = value if isinstance(value, bytes) else bytes(value)
            elif value is None:
                doc.pop(name, None)
            elif name in NUMERIC_FIELDS:
                doc[name] = int(value)
            else:
                doc[name] = value
        doc[key] = row.get(key)
        return doc

    def doc_to_row(self, doc: Mapping[str, Any], collection: str) -> dict:
        key = self._key(collection)
        spec = self.SPECS[collection]
        payload = {
            field: _jsonable(value)
            for field, value in doc.items()
            if field not in spec["columns"] and field not in (key, "_id")
        }
        row: dict[str, Any] = {key: str(doc.get(key, ""))}
        for name in spec["columns"]:
            row[name] = (
                _as_bytes(doc.get(name)) if name in self.BLOB_FIELDS else _promoted(doc.get(name))
            )
        row["doc"] = payload
        return row

    # -------------------------------------------------------------- JSON expr
    def _json_expr(self, table: Table, field: str):
        path = "$" + "".join(f'."{part}"' for part in field.split("."))
        extracted = func.json_extract(table.c["doc"], path)
        # MySQL/MariaDB wraps scalars in JSON quotes; SQLite returns them raw.
        return func.json_unquote(extracted) if self.is_mysql else extracted

    # ------------------------------------------------------------- conditions
    def _condition(self, table: Table, field: str, op: str, value: Any):
        col = table.c.get(field)
        if col is None:
            return self._json_condition(table, field, op, value)
        if op == "$regex":
            return col.like(_like_pattern(value), escape="\\")
        if op == "$in":
            return col.in_(list(value))
        if op == "$exists":
            return col.is_not(None) if value else col.is_(None)
        if op == "$gt":
            return col > value
        if op == "$gte":
            return col >= value
        if op == "$lt":
            return col < value
        if op == "$lte":
            return col <= value
        if op == "$ne":
            return or_(col.is_(None), col != value)
        return col == value

    def _json_condition(self, table: Table, field: str, op: str, value: Any):
        expr = self._json_expr(table, field)
        if op == "$regex":
            return func.lower(expr).like(_like_pattern(value).lower(), escape="\\")
        if op == "$in":
            return expr.in_([_jsonable(v) for v in value])
        if op == "$exists":
            return expr.is_not(None) if value else expr.is_(None)
        if op == "$gt":
            return expr > value
        if op == "$gte":
            return expr >= value
        if op == "$lt":
            return expr < value
        if op == "$lte":
            return expr <= value
        if op == "$ne":
            return or_(expr.is_(None), expr != value)
        return expr == _jsonable(value)

    def _where(self, table: Table, filter_: Mapping[str, Any]):
        clauses = []
        for field, cond in filter_.items():
            if field == "$or":
                clauses.append(or_(*[self._where(table, sub) for sub in cond]))
                continue
            if isinstance(cond, Mapping) and any(str(k).startswith("$") for k in cond):
                for op, value in cond.items():
                    if op == "$options":
                        # Case-insensitivity comes from the column collation
                        # (utf8mb4_general_ci on MariaDB, ASCII on SQLite).
                        continue
                    clauses.append(self._condition(table, field, str(op), value))
            else:
                clauses.append(self._condition(table, field, "$eq", cond))
        return and_(*clauses) if clauses else and_(True)

    def _order_by(self, table: Table, sort: Sequence[tuple[str, int]]):
        cols = []
        for field, direction in sort:
            col = table.c.get(field)
            if col is not None and not isinstance(col.type, JSON):
                cols.append(col.desc() if direction < 0 else col.asc())
        return cols

    @staticmethod
    def _project(doc: dict, projection: Mapping[str, Any]) -> dict:
        keeping = [f for f, v in projection.items() if v and f != "_id"]
        if not projection or not keeping:
            return doc
        return {f: doc[f] for f in keeping if f in doc}

    # ------------------------------------------------------------------ read
    async def fetch(
        self,
        collection: str,
        filter_: Mapping[str, Any],
        projection: Mapping[str, Any],
        sort: Sequence[tuple[str, int]],
        limit: int | None,
    ) -> list[dict]:
        table = self.table_for(collection)
        stmt = select(table).where(self._where(table, filter_))
        order = self._order_by(table, sort)
        if order:
            stmt = stmt.order_by(*order)
        if limit:
            stmt = stmt.limit(limit)
        async with self.engine.connect() as conn:
            rows = (await conn.execute(stmt)).mappings().all()
        return [self._project(self.row_to_doc(r, collection), projection) for r in rows]

    async def find_one(
        self,
        collection: str,
        filter_: Mapping[str, Any],
        projection: Mapping[str, Any],
        sort: Sequence[tuple[str, int]] | None = None,
    ) -> dict | None:
        rows = await self.fetch(collection, filter_, projection, sort or [], 1)
        return rows[0] if rows else None

    # ----------------------------------------------------------------- write
    async def insert(self, collection: str, docs: Sequence[dict]) -> list:
        table = self.table_for(collection)
        key = self._key(collection)
        inserted = []
        async with self.engine.begin() as conn:
            for doc in docs:
                row = self.doc_to_row(doc, collection)
                try:
                    await conn.execute(sa_insert(table).values(**row))
                except Exception as exc:  # noqa: BLE001 - normalise driver errors
                    raise DuplicateKeyError(str(exc)) from exc
                inserted.append(row[key])
        return inserted

    async def update(
        self,
        collection: str,
        filter_: Mapping[str, Any],
        change: Mapping[str, Any],
        upsert: bool = False,
        return_document: bool = False,
    ) -> dict | None:
        table = self.table_for(collection)
        key = self._key(collection)
        set_doc, inc_doc = _split_change(change)

        async with self.engine.begin() as conn:
            existing = (
                await conn.execute(select(table).where(self._where(table, filter_)))
            ).mappings().first()

            if existing is None:
                if not upsert:
                    return None
                seed: dict[str, Any] = {}
                for field, value in filter_.items():
                    if not str(field).startswith("$") and not isinstance(value, Mapping):
                        seed[field] = value
                for field, value in set_doc.items():
                    _set_path(seed, field, value)
                for field, amount in inc_doc.items():
                    _set_path(seed, field, (_get_path(seed, field) or 0) + amount)
                row = self.doc_to_row(seed, collection)
                try:
                    await conn.execute(sa_insert(table).values(**row))
                except Exception as exc:  # noqa: BLE001
                    raise DuplicateKeyError(str(exc)) from exc
                return self.row_to_doc(row, collection) if return_document else None

            doc = self.row_to_doc(existing, collection)
            for field, value in set_doc.items():
                _set_path(doc, field, value)
            for field, amount in inc_doc.items():
                _set_path(doc, field, (_get_path(doc, field) or 0) + amount)

            row = self.doc_to_row(doc, collection)
            await conn.execute(
                sa_update(table)
                .where(table.c[key] == existing[key])
                .values(**{k: v for k, v in row.items() if k != key})
            )
            return doc if return_document else None

    async def update_many(
        self, collection: str, filter_: Mapping[str, Any], change: Mapping[str, Any]
    ) -> UpdateResult:
        table = self.table_for(collection)
        key = self._key(collection)
        set_doc, inc_doc = _split_change(change)
        async with self.engine.begin() as conn:
            rows = (
                await conn.execute(select(table).where(self._where(table, filter_)))
            ).mappings().all()
            for existing in rows:
                doc = self.row_to_doc(existing, collection)
                for field, value in set_doc.items():
                    _set_path(doc, field, value)
                for field, amount in inc_doc.items():
                    _set_path(doc, field, (_get_path(doc, field) or 0) + amount)
                row = self.doc_to_row(doc, collection)
                await conn.execute(
                    sa_update(table)
                    .where(table.c[key] == existing[key])
                    .values(**{k: v for k, v in row.items() if k != key})
                )
        return UpdateResult(len(rows), len(rows))

    async def delete(self, collection: str, filter_: Mapping[str, Any]) -> int:
        table = self.table_for(collection)
        async with self.engine.begin() as conn:
            result = await conn.execute(delete(table).where(self._where(table, filter_)))
        return result.rowcount or 0

    async def count(self, collection: str, filter_: Mapping[str, Any]) -> int:
        table = self.table_for(collection)
        stmt = select(func.count()).select_from(table).where(self._where(table, filter_))
        async with self.engine.connect() as conn:
            return int((await conn.execute(stmt)).scalar_one())

    async def distinct(self, collection: str, field: str, filter_: Mapping[str, Any]) -> list:
        table = self.table_for(collection)
        col = table.c.get(field)
        if col is None or isinstance(col.type, JSON):
            rows = await self.fetch(collection, filter_, {}, [], None)
            values = {_get_path(r, field) for r in rows}
        else:
            stmt = select(col).where(self._where(table, filter_))
            async with self.engine.connect() as conn:
                values = {r[0] for r in (await conn.execute(stmt)).all()}
        return sorted((v for v in values if v is not None), key=str)


# --------------------------------------------------------------------- helpers
def _promoted(value: Any) -> Any:
    """Reduce a document value to something a promoted column can store."""
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float, str, datetime)):
        return value
    return None


def _as_bytes(value: Any) -> bytes | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    if isinstance(value, str):
        return value.encode("utf-8")
    return bytes(value)  # type: ignore[arg-type]


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).decode("utf-8", "replace")
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    return str(value)


def _split_change(change: Mapping[str, Any]) -> tuple[dict, dict]:
    set_doc: dict[str, Any] = {}
    inc_doc: dict[str, Any] = {}
    for field, value in change.items():
        if field == "$set":
            set_doc.update(value)
        elif field == "$inc":
            inc_doc.update(value)
        elif str(field).startswith("$"):
            raise ValueError(f"Unsupported update operator: {field}")
        else:
            set_doc[field] = value
    return set_doc, inc_doc


def _get_path(doc: Mapping[str, Any], path: str) -> Any:
    cur: Any = doc
    for part in path.split("."):
        if not isinstance(cur, Mapping):
            return None
        cur = cur.get(part)
    return cur


def _set_path(doc: dict, path: str, value: Any) -> None:
    parts = path.split(".")
    cur: dict = doc
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[part] = nxt
        cur = nxt
    cur[parts[-1]] = value


def _like_pattern(value: Any) -> str:
    """Turn a Mongo-style ^...$ regex into a SQL LIKE pattern.

    Route code builds these patterns with ``re.escape``, which also escapes
    characters SQL LIKE does not treat as special (notably the space). SQLite
    rejects an ESCAPE sequence followed by anything other than ``%``, ``_`` or
    the escape character itself, so backslash escapes are unfolded first and
    only ``%``/``_`` are escaped for LIKE.
    """
    text = value.pattern if isinstance(value, re.Pattern) else str(value)
    anchored = text.startswith("^") and text.endswith("$")
    if anchored:
        text = text[1:-1]
    text = re.sub(r"\\(.)", r"\1", text)
    text = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return text if anchored else f"%{text}%"
