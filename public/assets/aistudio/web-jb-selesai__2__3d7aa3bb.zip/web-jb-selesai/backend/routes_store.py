import re

from fastapi import APIRouter, HTTPException, Depends, Response, Body, Request

from db import products, testimonials, transactions, users, files, social_links, clean, now_iso
from auth import require_user, get_user_optional
from reviews import (
    PUBLIC_REVIEW_PROJECTION,
    public_review,
    refresh_product_rating,
    review_eligibility,
    submit_review,
)

router = APIRouter()


@router.get("/")
async def api_root():
    return {"message": "WillJustPlay API online"}


def _public(p: dict) -> dict:
    p.pop("paykita", None)
    return p


@router.get("/products")
async def list_products(game: str | None = None, category: str | None = None, q: str | None = None):
    query = {}
    if game and game != "Semua Game":
        query["game"] = {"$regex": f"^{re.escape(game)}$", "$options": "i"}
    if category and category != "Semua Kategori":
        query["category"] = {"$regex": f"^{re.escape(category)}$", "$options": "i"}
    if q:
        rx = {"$regex": re.escape(q), "$options": "i"}
        query["$or"] = [{"title": rx}, {"description": rx}, {"game": rx}]
    rows = await products.find(query, {"_id": 0}).to_list(length=1000)
    return [_public(p) for p in rows]


@router.get("/products/{product_id}")
async def get_product(product_id: str):
    product = await products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Produk tidak ditemukan")
    return _public(product)


@router.get("/games")
async def list_games():
    names = await products.distinct("game")
    return sorted([n for n in names if n])


@router.get("/testimonials")
async def list_testimonials(limit: int = 60):
    """Public review feed.

    The projection is explicit so private moderation fields (``buyer_email``,
    ``order_id``) can never leak through this endpoint.
    """
    rows = await testimonials.find({}, PUBLIC_REVIEW_PROJECTION).sort("created_at", -1).to_list(
        length=max(1, min(limit, 200))
    )
    return [public_review(r) for r in rows]


@router.get("/social-links")
async def list_social_links():
    return await social_links.find({"is_active": True}, {"_id": 0}).sort("seq", 1).to_list(length=100)


@router.get("/me/orders")
async def my_orders(user: dict = Depends(require_user)):
    orders = await transactions.find(
        {"user_id": user["id"]}, {"_id": 0, "payment_proof": 0, "snap_token": 0, "paykita_raw": 0, "webhook_payload": 0}
    ).sort("created_at", -1).to_list(length=500)
    for o in orders:
        if o.get("payment_status") != "paid":
            o.pop("delivery_info", None)
    return orders


@router.get("/me/wishlist")
async def my_wishlist(user: dict = Depends(require_user)):
    ids = user.get("wishlist") or []
    if not ids:
        return []
    return await products.find({"id": {"$in": ids}}, {"_id": 0}).to_list(length=1000)


@router.post("/me/wishlist/{product_id}")
async def toggle_wishlist(product_id: str, user: dict = Depends(require_user)):
    wishlist = list(user.get("wishlist") or [])
    if product_id in wishlist:
        wishlist.remove(product_id)
    else:
        wishlist.append(product_id)
    await users.update_one({"id": user["id"]}, {"$set": {"wishlist": wishlist}})
    return {"wishlist": wishlist}


@router.get("/files/{path:path}")
async def serve_file(path: str):
    rec = await files.find_one({"path": path})
    if not rec:
        raise HTTPException(404, "File tidak ditemukan")
    return Response(content=bytes(rec["data"]), media_type=rec["content_type"],
                    headers={"Cache-Control": "public, max-age=31536000, immutable"})


# ---------------- Buyer reviews ----------------
@router.get("/reviews/eligibility/{session_id}")
async def review_eligibility_endpoint(session_id: str, request: Request, email: str | None = None):
    """Can this order be reviewed? Requires the owner's token or the buyer email."""
    user = await get_user_optional(request)
    return await review_eligibility(session_id, user, email)


@router.post("/reviews", status_code=201)
async def create_review(request: Request, body: dict = Body(...)):
    return await submit_review(request, body)


@router.get("/products/{product_id}/reviews")
async def product_reviews(product_id: str):
    if not await products.find_one({"id": product_id}, {"_id": 0, "id": 1}):
        raise HTTPException(404, "Produk tidak ditemukan")
    rows = await testimonials.find(
        {"product_id": product_id, "verified": True}, PUBLIC_REVIEW_PROJECTION
    ).sort("created_at", -1).to_list(length=200)
    reviews = [public_review(r) for r in rows]
    average = round(sum(r["rating"] for r in reviews) / len(reviews), 1) if reviews else 0
    return {
        "product_id": product_id,
        "count": len(reviews),
        "average": average,
        "distribution": {str(n): sum(1 for r in reviews if r["rating"] == n) for n in range(5, 0, -1)},
        "reviews": reviews,
    }


@router.get("/reviews/mine")
async def my_reviews(user: dict = Depends(require_user)):
    rows = await testimonials.find(
        {"user_id": user["id"]}, PUBLIC_REVIEW_PROJECTION
    ).sort("created_at", -1).to_list(length=500)
    return [public_review(r) for r in rows]
