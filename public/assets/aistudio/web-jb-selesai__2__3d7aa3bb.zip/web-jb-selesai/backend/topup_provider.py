"""Compatibility shim.

Supplier integrations live in :mod:`topup_vendors` (database-backed suppliers,
Digiflazz included). This module keeps the original import surface used by the
route modules so they do not need to change.
"""

from __future__ import annotations

from topup_vendors import (  # noqa: F401  (re-exported API)
    AccountCheck,
    Fulfilment,
    ManualVendor,
    TopupVendor,
    active_vendor,
    check_account,
    fulfil,
)

# Kept for backwards compatibility with earlier revisions of this module.
ManualProvider = ManualVendor
TopupProvider = TopupVendor


async def get_provider() -> TopupVendor:
    """Resolve the supplier currently used for automatic operations."""
    return await active_vendor()


__all__ = [
    "AccountCheck",
    "Fulfilment",
    "ManualProvider",
    "ManualVendor",
    "TopupProvider",
    "TopupVendor",
    "active_vendor",
    "check_account",
    "fulfil",
    "get_provider",
]
