"""Transactional email.

Two providers are supported, selected by which credentials are present:

    RESEND_API_KEY            Resend (https://resend.com) — preferred
    EMERGENT_EMAIL_KEY        legacy Emergent integrations gateway

Verification and reset links are built from ``FRONTEND_URL`` and every message
is validated by :func:`_assert_safe_email` before it leaves the process.
"""

import os
import re
import ipaddress
import logging
import httpx
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse

logger = logging.getLogger("mailer")

RESEND_ENDPOINT = "https://api.resend.com/emails"
EMAIL_BASE_URL = "https://integrations.emergentagent.com"

RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
EMAIL_KEY = os.environ.get("EMERGENT_EMAIL_KEY", "")

EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "WillJustPlay")
EMAIL_FROM_ADDRESS = os.environ.get("EMAIL_FROM", "").strip()
EMAIL_REPLY_TO = os.environ.get("EMAIL_REPLY_TO")
BRAND = EMAIL_FROM_NAME


def mailer_name() -> str:
    """Which provider will be used for the next send."""
    if RESEND_API_KEY:
        return "resend"
    if EMAIL_KEY:
        return "emergent"
    return "none"


def is_configured() -> bool:
    return bool(RESEND_API_KEY or EMAIL_KEY)


def from_address() -> str:
    """RFC 5322 From header for Resend (falls back to Resend's test sender)."""
    if EMAIL_FROM_ADDRESS:
        return f"{EMAIL_FROM_NAME} <{EMAIL_FROM_ADDRESS}>"
    return f"{EMAIL_FROM_NAME} <onboarding@resend.dev>"


_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r} (G2)")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r} (G3)")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r} (G3)")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != real link host {real!r} (G3)")


async def _send_via_resend(to: str, subject: str, html: str) -> bool:
    payload = {
        "from": from_address(),
        "to": [to],
        "subject": subject,
        "html": html,
    }
    if EMAIL_REPLY_TO:
        payload["reply_to"] = EMAIL_REPLY_TO
    async with httpx.AsyncClient(timeout=30) as http:
        resp = await http.post(
            RESEND_ENDPOINT,
            headers={
                "Authorization": f"Bearer {RESEND_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
    if resp.status_code >= 400:
        # Surface Resend's reason (domain not verified, invalid from, ...)
        logger.error("Resend rejected email to %s: %s %s", to, resp.status_code, resp.text[:300])
        return False
    return True


async def _send_via_emergent(to: str, subject: str, html: str) -> bool:
    payload = {"to": [to], "subject": subject, "html": html, "from_name": EMAIL_FROM_NAME}
    if EMAIL_REPLY_TO:
        payload["contact_email"] = EMAIL_REPLY_TO
    async with httpx.AsyncClient(timeout=30) as http:
        resp = await http.post(
            f"{EMAIL_BASE_URL}/api/v1/email/send",
            headers={"X-Email-Key": EMAIL_KEY},
            json=payload,
        )
    resp.raise_for_status()
    return True


async def send_email(to: str, subject: str, html: str) -> bool:
    provider = mailer_name()
    if provider == "none":
        logger.warning("No email provider configured; email to %s skipped", to)
        return False
    try:
        _assert_safe_email(subject, html)
    except ValueError as exc:
        logger.error("Refusing to send email to %s: %s", to, exc)
        return False
    try:
        if provider == "resend":
            return await _send_via_resend(to, subject, html)
        return await _send_via_emergent(to, subject, html)
    except Exception as exc:
        logger.error("Failed to send email to %s via %s: %s", to, provider, exc)
        return False


def _button(url: str, label: str) -> str:
    return (
        f'<a href="{url}" style="display:inline-block;padding:12px 24px;background-color:#00F0FF;'
        f'color:#07080B;text-decoration:none;font-weight:bold;border-radius:6px;">{escape(label)}</a>'
    )


def _wrap(title: str, body: str) -> str:
    return (
        '<table role="presentation" width="100%" style="font-family:Arial,sans-serif;background:#0B0D12;">'
        '<tr><td style="padding:32px;"><table role="presentation" width="520" align="center" '
        'style="max-width:520px;color:#F4F6FA;">'
        f'<tr><td><p style="font-size:12px;letter-spacing:3px;color:#00F0FF;margin:0 0 16px;">{escape(BRAND.upper())}</p>'
        f'<h2 style="margin:0 0 16px;color:#F4F6FA;">{escape(title)}</h2>{body}'
        f'<p style="margin-top:32px;font-size:12px;color:#8A93A6;">Dikirim oleh {escape(BRAND)}. '
        f'Kami tidak pernah meminta password atau detail kartu Anda melalui email.</p>'
        '</td></tr></table></td></tr></table>'
    )


async def send_verification_email(to: str, name: str, url: str) -> bool:
    body = (
        f"<p>Halo {escape(name)},</p>"
        f"<p>Terima kasih telah mendaftar di {escape(BRAND)}. Klik tombol di bawah untuk memverifikasi alamat email kamu:</p>"
        f'<p style="margin:24px 0;">{_button(url, "Verifikasi Email")}</p>'
        f'<p style="color:#8A93A6;font-size:13px;">Tautan ini kedaluwarsa dalam 24 jam.</p>'
    )
    return await send_email(to, f"Verifikasi Akun {BRAND}", _wrap("Verifikasi Email Kamu", body))


async def send_reset_email(to: str, name: str, url: str) -> bool:
    body = (
        f"<p>Halo {escape(name)},</p>"
        f"<p>Ada permintaan untuk mereset password akun {escape(BRAND)} kamu. Klik tombol di bawah untuk melanjutkan:</p>"
        f'<p style="margin:24px 0;">{_button(url, "Reset Password")}</p>'
        f'<p style="color:#8A93A6;font-size:13px;">Tautan berlaku 1 jam. Jika kamu tidak meminta reset, abaikan email ini.</p>'
    )
    return await send_email(to, f"Reset Password Akun {BRAND}", _wrap("Reset Password", body))
