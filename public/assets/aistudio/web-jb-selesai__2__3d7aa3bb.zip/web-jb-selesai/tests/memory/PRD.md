# WillJustPlay — PRD

## Original Problem Statement
User imported an existing full-stack app (GitHub: husnul7723-blip/done-jb) and requested a **live deployment** (selected option "B: Deploy live"). The app failed pre-deployment checks because the `.env` files were missing (not committed to git).

## Product
WillJustPlay — Indonesian game marketplace ("Beli Akun Game & Jasa Joki Instant"). Cyberpunk neon (cyan/magenta on dark) aesthetic. Sells game accounts, top-ups, and boosting (joki) services with 100% guarantee.

## Tech Stack
- Frontend: React (CRA + CRACO), Tailwind, shadcn/ui
- Backend: FastAPI (routes: auth, store, admin, payments)
- DB: MongoDB (motor)
- Payments: PayKita gateway (configured via admin DB settings)
- Email: Emergent integrations mailer (optional; auto-verify when unconfigured)

## Required Environment Variables
Backend (`/app/backend/.env`):
- MONGO_URL, DB_NAME
- JWT_SECRET
- ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_KEY
- FRONTEND_URL
- CORS_ORIGINS, EMAIL_FROM_NAME (optional: EMERGENT_EMAIL_KEY, EMAIL_REPLY_TO)

Frontend (`/app/frontend/.env`):
- REACT_APP_BACKEND_URL

## Status (2026-06)
- [DONE] Recreated missing `.env` files for frontend + backend.
- [DONE] Verified: /api/health ok, /api/products seeded, admin-login works, frontend renders.
- [IN PROGRESS] Live deployment via deployer.

## Backlog / Future
- P1: Configure EMERGENT_EMAIL_KEY to enable real email verification + password reset.
- P2: Configure live PayKita credentials in admin panel before accepting real payments.
